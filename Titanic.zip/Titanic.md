```python
import pandas as pd
```


```python
df=pd.read_csv("C:\\Users\\SHAASHANK JOSHI\\Downloads\\Data_Train.xlsx - Sheet1.csv")
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Airline</th>
      <th>Date_of_Journey</th>
      <th>Source</th>
      <th>Destination</th>
      <th>Route</th>
      <th>Dep_Time</th>
      <th>Arrival_Time</th>
      <th>Duration</th>
      <th>Total_Stops</th>
      <th>Additional_Info</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>IndiGo</td>
      <td>24/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → DEL</td>
      <td>22:20</td>
      <td>01:10 22 Mar</td>
      <td>2h 50m</td>
      <td>non-stop</td>
      <td>No info</td>
      <td>3897</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Air India</td>
      <td>1/05/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → IXR → BBI → BLR</td>
      <td>05:50</td>
      <td>13:15</td>
      <td>7h 25m</td>
      <td>2 stops</td>
      <td>No info</td>
      <td>7662</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Jet Airways</td>
      <td>9/06/2019</td>
      <td>Delhi</td>
      <td>Cochin</td>
      <td>DEL → LKO → BOM → COK</td>
      <td>09:25</td>
      <td>04:25 10 Jun</td>
      <td>19h</td>
      <td>2 stops</td>
      <td>No info</td>
      <td>13882</td>
    </tr>
    <tr>
      <th>3</th>
      <td>IndiGo</td>
      <td>12/05/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → NAG → BLR</td>
      <td>18:05</td>
      <td>23:30</td>
      <td>5h 25m</td>
      <td>1 stop</td>
      <td>No info</td>
      <td>6218</td>
    </tr>
    <tr>
      <th>4</th>
      <td>IndiGo</td>
      <td>01/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → NAG → DEL</td>
      <td>16:50</td>
      <td>21:35</td>
      <td>4h 45m</td>
      <td>1 stop</td>
      <td>No info</td>
      <td>13302</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>10678</th>
      <td>Air Asia</td>
      <td>9/04/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → BLR</td>
      <td>19:55</td>
      <td>22:25</td>
      <td>2h 30m</td>
      <td>non-stop</td>
      <td>No info</td>
      <td>4107</td>
    </tr>
    <tr>
      <th>10679</th>
      <td>Air India</td>
      <td>27/04/2019</td>
      <td>Kolkata</td>
      <td>Banglore</td>
      <td>CCU → BLR</td>
      <td>20:45</td>
      <td>23:20</td>
      <td>2h 35m</td>
      <td>non-stop</td>
      <td>No info</td>
      <td>4145</td>
    </tr>
    <tr>
      <th>10680</th>
      <td>Jet Airways</td>
      <td>27/04/2019</td>
      <td>Banglore</td>
      <td>Delhi</td>
      <td>BLR → DEL</td>
      <td>08:20</td>
      <td>11:20</td>
      <td>3h</td>
      <td>non-stop</td>
      <td>No info</td>
      <td>7229</td>
    </tr>
    <tr>
      <th>10681</th>
      <td>Vistara</td>
      <td>01/03/2019</td>
      <td>Banglore</td>
      <td>New Delhi</td>
      <td>BLR → DEL</td>
      <td>11:30</td>
      <td>14:10</td>
      <td>2h 40m</td>
      <td>non-stop</td>
      <td>No info</td>
      <td>12648</td>
    </tr>
    <tr>
      <th>10682</th>
      <td>Air India</td>
      <td>9/05/2019</td>
      <td>Delhi</td>
      <td>Cochin</td>
      <td>DEL → GOI → BOM → COK</td>
      <td>10:55</td>
      <td>19:15</td>
      <td>8h 20m</td>
      <td>2 stops</td>
      <td>No info</td>
      <td>11753</td>
    </tr>
  </tbody>
</table>
<p>10683 rows × 11 columns</p>
</div>




```python
df.shape
```




    (10683, 11)




```python
df1=pd.read_csv("C:\\Users\\SHAASHANK JOSHI\\Downloads\\train_bikes.csv")
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>datetime</th>
      <th>season</th>
      <th>holiday</th>
      <th>workingday</th>
      <th>weather</th>
      <th>temp</th>
      <th>atemp</th>
      <th>humidity</th>
      <th>windspeed</th>
      <th>casual</th>
      <th>registered</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2011-01-01 00:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>81</td>
      <td>0.0000</td>
      <td>3</td>
      <td>13</td>
      <td>16</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2011-01-01 01:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0000</td>
      <td>8</td>
      <td>32</td>
      <td>40</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2011-01-01 02:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.02</td>
      <td>13.635</td>
      <td>80</td>
      <td>0.0000</td>
      <td>5</td>
      <td>27</td>
      <td>32</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2011-01-01 03:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0000</td>
      <td>3</td>
      <td>10</td>
      <td>13</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2011-01-01 04:00:00</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>9.84</td>
      <td>14.395</td>
      <td>75</td>
      <td>0.0000</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>10881</th>
      <td>2012-12-19 19:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>15.58</td>
      <td>19.695</td>
      <td>50</td>
      <td>26.0027</td>
      <td>7</td>
      <td>329</td>
      <td>336</td>
    </tr>
    <tr>
      <th>10882</th>
      <td>2012-12-19 20:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>14.76</td>
      <td>17.425</td>
      <td>57</td>
      <td>15.0013</td>
      <td>10</td>
      <td>231</td>
      <td>241</td>
    </tr>
    <tr>
      <th>10883</th>
      <td>2012-12-19 21:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>15.910</td>
      <td>61</td>
      <td>15.0013</td>
      <td>4</td>
      <td>164</td>
      <td>168</td>
    </tr>
    <tr>
      <th>10884</th>
      <td>2012-12-19 22:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.94</td>
      <td>17.425</td>
      <td>61</td>
      <td>6.0032</td>
      <td>12</td>
      <td>117</td>
      <td>129</td>
    </tr>
    <tr>
      <th>10885</th>
      <td>2012-12-19 23:00:00</td>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>13.12</td>
      <td>16.665</td>
      <td>66</td>
      <td>8.9981</td>
      <td>4</td>
      <td>84</td>
      <td>88</td>
    </tr>
  </tbody>
</table>
<p>10886 rows × 12 columns</p>
</div>




```python
df1=pd.read_csv("C:\\Users\\SHAASHANK JOSHI\\Downloads\\train.csv")
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Ticket</th>
      <th>Fare</th>
      <th>Cabin</th>
      <th>Embarked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>A/5 21171</td>
      <td>7.2500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>PC 17599</td>
      <td>71.2833</td>
      <td>C85</td>
      <td>C</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>STON/O2. 3101282</td>
      <td>7.9250</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>113803</td>
      <td>53.1000</td>
      <td>C123</td>
      <td>S</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>373450</td>
      <td>8.0500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>886</th>
      <td>887</td>
      <td>0</td>
      <td>2</td>
      <td>Montvila, Rev. Juozas</td>
      <td>male</td>
      <td>27.0</td>
      <td>0</td>
      <td>0</td>
      <td>211536</td>
      <td>13.0000</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>887</th>
      <td>888</td>
      <td>1</td>
      <td>1</td>
      <td>Graham, Miss. Margaret Edith</td>
      <td>female</td>
      <td>19.0</td>
      <td>0</td>
      <td>0</td>
      <td>112053</td>
      <td>30.0000</td>
      <td>B42</td>
      <td>S</td>
    </tr>
    <tr>
      <th>888</th>
      <td>889</td>
      <td>0</td>
      <td>3</td>
      <td>Johnston, Miss. Catherine Helen "Carrie"</td>
      <td>female</td>
      <td>NaN</td>
      <td>1</td>
      <td>2</td>
      <td>W./C. 6607</td>
      <td>23.4500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>889</th>
      <td>890</td>
      <td>1</td>
      <td>1</td>
      <td>Behr, Mr. Karl Howell</td>
      <td>male</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>111369</td>
      <td>30.0000</td>
      <td>C148</td>
      <td>C</td>
    </tr>
    <tr>
      <th>890</th>
      <td>891</td>
      <td>0</td>
      <td>3</td>
      <td>Dooley, Mr. Patrick</td>
      <td>male</td>
      <td>32.0</td>
      <td>0</td>
      <td>0</td>
      <td>370376</td>
      <td>7.7500</td>
      <td>NaN</td>
      <td>Q</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 12 columns</p>
</div>




```python
df1.sample(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Ticket</th>
      <th>Fare</th>
      <th>Cabin</th>
      <th>Embarked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>511</th>
      <td>512</td>
      <td>0</td>
      <td>3</td>
      <td>Webber, Mr. James</td>
      <td>male</td>
      <td>NaN</td>
      <td>0</td>
      <td>0</td>
      <td>SOTON/OQ 3101316</td>
      <td>8.0500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>823</th>
      <td>824</td>
      <td>1</td>
      <td>3</td>
      <td>Moor, Mrs. (Beila)</td>
      <td>female</td>
      <td>27.0</td>
      <td>0</td>
      <td>1</td>
      <td>392096</td>
      <td>12.4750</td>
      <td>E121</td>
      <td>S</td>
    </tr>
    <tr>
      <th>733</th>
      <td>734</td>
      <td>0</td>
      <td>2</td>
      <td>Berriman, Mr. William John</td>
      <td>male</td>
      <td>23.0</td>
      <td>0</td>
      <td>0</td>
      <td>28425</td>
      <td>13.0000</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>705</th>
      <td>706</td>
      <td>0</td>
      <td>2</td>
      <td>Morley, Mr. Henry Samuel ("Mr Henry Marshall")</td>
      <td>male</td>
      <td>39.0</td>
      <td>0</td>
      <td>0</td>
      <td>250655</td>
      <td>26.0000</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>381</th>
      <td>382</td>
      <td>1</td>
      <td>3</td>
      <td>Nakid, Miss. Maria ("Mary")</td>
      <td>female</td>
      <td>1.0</td>
      <td>0</td>
      <td>2</td>
      <td>2653</td>
      <td>15.7417</td>
      <td>NaN</td>
      <td>C</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1.dtypes
```




    PassengerId      int64
    Survived         int64
    Pclass           int64
    Name            object
    Sex             object
    Age            float64
    SibSp            int64
    Parch            int64
    Ticket          object
    Fare           float64
    Cabin           object
    Embarked        object
    dtype: object



from this above output we can see that survived and pclass are of iny=t type but we have to change in object


```python
df1.columns  #reading column name
```




    Index(['PassengerId', 'Survived', 'Pclass', 'Name', 'Sex', 'Age', 'SibSp',
           'Parch', 'Ticket', 'Fare', 'Cabin', 'Embarked'],
          dtype='object')




```python
df1.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 891 entries, 0 to 890
    Data columns (total 12 columns):
     #   Column       Non-Null Count  Dtype  
    ---  ------       --------------  -----  
     0   PassengerId  891 non-null    int64  
     1   Survived     891 non-null    int64  
     2   Pclass       891 non-null    int64  
     3   Name         891 non-null    object 
     4   Sex          891 non-null    object 
     5   Age          714 non-null    float64
     6   SibSp        891 non-null    int64  
     7   Parch        891 non-null    int64  
     8   Ticket       891 non-null    object 
     9   Fare         891 non-null    float64
     10  Cabin        204 non-null    object 
     11  Embarked     889 non-null    object 
    dtypes: float64(2), int64(5), object(5)
    memory usage: 83.7+ KB
    


```python
df1.isnull().sum()
```




    PassengerId      0
    Survived         0
    Pclass           0
    Name             0
    Sex              0
    Age            177
    SibSp            0
    Parch            0
    Ticket           0
    Fare             0
    Cabin          687
    Embarked         2
    dtype: int64




```python
df1.isnull().sum()*100/df1.shape[0]
```




    PassengerId     0.000000
    Survived        0.000000
    Pclass          0.000000
    Name            0.000000
    Sex             0.000000
    Age            19.865320
    SibSp           0.000000
    Parch           0.000000
    Ticket          0.000000
    Fare            0.000000
    Cabin          77.104377
    Embarked        0.224467
    dtype: float64




```python
for i in df1.columns:
    if df1[i].isnull().any():
        print(i,".......",df1[i].isnull().sum()*100/df1.shape[0])
```

    Age ....... 19.865319865319865
    Cabin ....... 77.10437710437711
    Embarked ....... 0.2244668911335578
    


```python
df1["Cabin"].unique()
```




    array([nan, 'C85', 'C123', 'E46', 'G6', 'C103', 'D56', 'A6',
           'C23 C25 C27', 'B78', 'D33', 'B30', 'C52', 'B28', 'C83', 'F33',
           'F G73', 'E31', 'A5', 'D10 D12', 'D26', 'C110', 'B58 B60', 'E101',
           'F E69', 'D47', 'B86', 'F2', 'C2', 'E33', 'B19', 'A7', 'C49', 'F4',
           'A32', 'B4', 'B80', 'A31', 'D36', 'D15', 'C93', 'C78', 'D35',
           'C87', 'B77', 'E67', 'B94', 'C125', 'C99', 'C118', 'D7', 'A19',
           'B49', 'D', 'C22 C26', 'C106', 'C65', 'E36', 'C54',
           'B57 B59 B63 B66', 'C7', 'E34', 'C32', 'B18', 'C124', 'C91', 'E40',
           'T', 'C128', 'D37', 'B35', 'E50', 'C82', 'B96 B98', 'E10', 'E44',
           'A34', 'C104', 'C111', 'C92', 'E38', 'D21', 'E12', 'E63', 'A14',
           'B37', 'C30', 'D20', 'B79', 'E25', 'D46', 'B73', 'C95', 'B38',
           'B39', 'B22', 'C86', 'C70', 'A16', 'C101', 'C68', 'A10', 'E68',
           'B41', 'A20', 'D19', 'D50', 'D9', 'A23', 'B50', 'A26', 'D48',
           'E58', 'C126', 'B71', 'B51 B53 B55', 'D49', 'B5', 'B20', 'F G63',
           'C62 C64', 'E24', 'C90', 'C45', 'E8', 'B101', 'D45', 'C46', 'D30',
           'E121', 'D11', 'E77', 'F38', 'B3', 'D6', 'B82 B84', 'D17', 'A36',
           'B102', 'B69', 'E49', 'C47', 'D28', 'E17', 'A24', 'C50', 'B42',
           'C148'], dtype=object)




```python
df1["Cabin"].fillna(df1["Cabin"].mode()[0],inplace=True)
```


```python
df1["cabin_name"]=df1["Cabin"].apply(lambda x:x[0])
```


```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Ticket</th>
      <th>Fare</th>
      <th>Cabin</th>
      <th>Embarked</th>
      <th>cabin_name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>A/5 21171</td>
      <td>7.2500</td>
      <td>B96 B98</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>PC 17599</td>
      <td>71.2833</td>
      <td>C85</td>
      <td>C</td>
      <td>C</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>STON/O2. 3101282</td>
      <td>7.9250</td>
      <td>B96 B98</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>113803</td>
      <td>53.1000</td>
      <td>C123</td>
      <td>S</td>
      <td>C</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>373450</td>
      <td>8.0500</td>
      <td>B96 B98</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>886</th>
      <td>887</td>
      <td>0</td>
      <td>2</td>
      <td>Montvila, Rev. Juozas</td>
      <td>male</td>
      <td>27.0</td>
      <td>0</td>
      <td>0</td>
      <td>211536</td>
      <td>13.0000</td>
      <td>B96 B98</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>887</th>
      <td>888</td>
      <td>1</td>
      <td>1</td>
      <td>Graham, Miss. Margaret Edith</td>
      <td>female</td>
      <td>19.0</td>
      <td>0</td>
      <td>0</td>
      <td>112053</td>
      <td>30.0000</td>
      <td>B42</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>888</th>
      <td>889</td>
      <td>0</td>
      <td>3</td>
      <td>Johnston, Miss. Catherine Helen "Carrie"</td>
      <td>female</td>
      <td>NaN</td>
      <td>1</td>
      <td>2</td>
      <td>W./C. 6607</td>
      <td>23.4500</td>
      <td>B96 B98</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>889</th>
      <td>890</td>
      <td>1</td>
      <td>1</td>
      <td>Behr, Mr. Karl Howell</td>
      <td>male</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>111369</td>
      <td>30.0000</td>
      <td>C148</td>
      <td>C</td>
      <td>C</td>
    </tr>
    <tr>
      <th>890</th>
      <td>891</td>
      <td>0</td>
      <td>3</td>
      <td>Dooley, Mr. Patrick</td>
      <td>male</td>
      <td>32.0</td>
      <td>0</td>
      <td>0</td>
      <td>370376</td>
      <td>7.7500</td>
      <td>B96 B98</td>
      <td>Q</td>
      <td>B</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 13 columns</p>
</div>




```python
df1["Embarked"].fillna(df1["Embarked"].mode()[0],inplace=True)
```


```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Ticket</th>
      <th>Fare</th>
      <th>Cabin</th>
      <th>Embarked</th>
      <th>cabin_name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>A/5 21171</td>
      <td>7.2500</td>
      <td>B96 B98</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>PC 17599</td>
      <td>71.2833</td>
      <td>C85</td>
      <td>C</td>
      <td>C</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>STON/O2. 3101282</td>
      <td>7.9250</td>
      <td>B96 B98</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>113803</td>
      <td>53.1000</td>
      <td>C123</td>
      <td>S</td>
      <td>C</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>373450</td>
      <td>8.0500</td>
      <td>B96 B98</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>886</th>
      <td>887</td>
      <td>0</td>
      <td>2</td>
      <td>Montvila, Rev. Juozas</td>
      <td>male</td>
      <td>27.0</td>
      <td>0</td>
      <td>0</td>
      <td>211536</td>
      <td>13.0000</td>
      <td>B96 B98</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>887</th>
      <td>888</td>
      <td>1</td>
      <td>1</td>
      <td>Graham, Miss. Margaret Edith</td>
      <td>female</td>
      <td>19.0</td>
      <td>0</td>
      <td>0</td>
      <td>112053</td>
      <td>30.0000</td>
      <td>B42</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>888</th>
      <td>889</td>
      <td>0</td>
      <td>3</td>
      <td>Johnston, Miss. Catherine Helen "Carrie"</td>
      <td>female</td>
      <td>NaN</td>
      <td>1</td>
      <td>2</td>
      <td>W./C. 6607</td>
      <td>23.4500</td>
      <td>B96 B98</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>889</th>
      <td>890</td>
      <td>1</td>
      <td>1</td>
      <td>Behr, Mr. Karl Howell</td>
      <td>male</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>111369</td>
      <td>30.0000</td>
      <td>C148</td>
      <td>C</td>
      <td>C</td>
    </tr>
    <tr>
      <th>890</th>
      <td>891</td>
      <td>0</td>
      <td>3</td>
      <td>Dooley, Mr. Patrick</td>
      <td>male</td>
      <td>32.0</td>
      <td>0</td>
      <td>0</td>
      <td>370376</td>
      <td>7.7500</td>
      <td>B96 B98</td>
      <td>Q</td>
      <td>B</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 13 columns</p>
</div>




```python

```


```python
import seaborn as sns
sns.boxplot(df1["Age"])
```

    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='Age'>




    
![png](output_21_2.png)
    



```python
df1["Age"].fillna(df1["Age"].median(),inplace=True)
```


```python

#from this out we will drop all the irrelevant columns
```


```python
df1.drop(columns=["PassengerId","Ticket"],inplace=True)
```


```python
df1.duplicated().sum()
```




    0




```python
for i in df1.columns:
    print(df1[i].unique())
```

    [0 1]
    [3 1 2]
    ['Braund, Mr. Owen Harris'
     'Cumings, Mrs. John Bradley (Florence Briggs Thayer)'
     'Heikkinen, Miss. Laina' 'Futrelle, Mrs. Jacques Heath (Lily May Peel)'
     'Allen, Mr. William Henry' 'Moran, Mr. James' 'McCarthy, Mr. Timothy J'
     'Palsson, Master. Gosta Leonard'
     'Johnson, Mrs. Oscar W (Elisabeth Vilhelmina Berg)'
     'Nasser, Mrs. Nicholas (Adele Achem)' 'Sandstrom, Miss. Marguerite Rut'
     'Bonnell, Miss. Elizabeth' 'Saundercock, Mr. William Henry'
     'Andersson, Mr. Anders Johan' 'Vestrom, Miss. Hulda Amanda Adolfina'
     'Hewlett, Mrs. (Mary D Kingcome) ' 'Rice, Master. Eugene'
     'Williams, Mr. Charles Eugene'
     'Vander Planke, Mrs. Julius (Emelia Maria Vandemoortele)'
     'Masselmani, Mrs. Fatima' 'Fynney, Mr. Joseph J' 'Beesley, Mr. Lawrence'
     'McGowan, Miss. Anna "Annie"' 'Sloper, Mr. William Thompson'
     'Palsson, Miss. Torborg Danira'
     'Asplund, Mrs. Carl Oscar (Selma Augusta Emilia Johansson)'
     'Emir, Mr. Farred Chehab' 'Fortune, Mr. Charles Alexander'
     'O\'Dwyer, Miss. Ellen "Nellie"' 'Todoroff, Mr. Lalio'
     'Uruchurtu, Don. Manuel E'
     'Spencer, Mrs. William Augustus (Marie Eugenie)'
     'Glynn, Miss. Mary Agatha' 'Wheadon, Mr. Edward H'
     'Meyer, Mr. Edgar Joseph' 'Holverson, Mr. Alexander Oskar'
     'Mamee, Mr. Hanna' 'Cann, Mr. Ernest Charles'
     'Vander Planke, Miss. Augusta Maria' 'Nicola-Yarred, Miss. Jamila'
     'Ahlin, Mrs. Johan (Johanna Persdotter Larsson)'
     'Turpin, Mrs. William John Robert (Dorothy Ann Wonnacott)'
     'Kraeff, Mr. Theodor' 'Laroche, Miss. Simonne Marie Anne Andree'
     'Devaney, Miss. Margaret Delia' 'Rogers, Mr. William John'
     'Lennon, Mr. Denis' "O'Driscoll, Miss. Bridget" 'Samaan, Mr. Youssef'
     'Arnold-Franchi, Mrs. Josef (Josefine Franchi)'
     'Panula, Master. Juha Niilo' 'Nosworthy, Mr. Richard Cater'
     'Harper, Mrs. Henry Sleeper (Myna Haxtun)'
     'Faunthorpe, Mrs. Lizzie (Elizabeth Anne Wilkinson)'
     'Ostby, Mr. Engelhart Cornelius' 'Woolner, Mr. Hugh' 'Rugg, Miss. Emily'
     'Novel, Mr. Mansouer' 'West, Miss. Constance Mirium'
     'Goodwin, Master. William Frederick' 'Sirayanian, Mr. Orsen'
     'Icard, Miss. Amelie' 'Harris, Mr. Henry Birkhardt'
     'Skoog, Master. Harald' 'Stewart, Mr. Albert A'
     'Moubarek, Master. Gerios' 'Nye, Mrs. (Elizabeth Ramell)'
     'Crease, Mr. Ernest James' 'Andersson, Miss. Erna Alexandra'
     'Kink, Mr. Vincenz' 'Jenkin, Mr. Stephen Curnow'
     'Goodwin, Miss. Lillian Amy' 'Hood, Mr. Ambrose Jr'
     'Chronopoulos, Mr. Apostolos' 'Bing, Mr. Lee' 'Moen, Mr. Sigurd Hansen'
     'Staneff, Mr. Ivan' 'Moutal, Mr. Rahamin Haim'
     'Caldwell, Master. Alden Gates' 'Dowdell, Miss. Elizabeth'
     'Waelens, Mr. Achille' 'Sheerlinck, Mr. Jan Baptist'
     'McDermott, Miss. Brigdet Delia' 'Carrau, Mr. Francisco M'
     'Ilett, Miss. Bertha'
     'Backstrom, Mrs. Karl Alfred (Maria Mathilda Gustafsson)'
     'Ford, Mr. William Neal' 'Slocovski, Mr. Selman Francis'
     'Fortune, Miss. Mabel Helen' 'Celotti, Mr. Francesco'
     'Christmann, Mr. Emil' 'Andreasson, Mr. Paul Edvin'
     'Chaffee, Mr. Herbert Fuller' 'Dean, Mr. Bertram Frank'
     'Coxon, Mr. Daniel' 'Shorney, Mr. Charles Joseph'
     'Goldschmidt, Mr. George B' 'Greenfield, Mr. William Bertram'
     'Doling, Mrs. John T (Ada Julia Bone)' 'Kantor, Mr. Sinai'
     'Petranec, Miss. Matilda' 'Petroff, Mr. Pastcho ("Pentcho")'
     'White, Mr. Richard Frasar' 'Johansson, Mr. Gustaf Joel'
     'Gustafsson, Mr. Anders Vilhelm' 'Mionoff, Mr. Stoytcho'
     'Salkjelsvik, Miss. Anna Kristine' 'Moss, Mr. Albert Johan'
     'Rekic, Mr. Tido' 'Moran, Miss. Bertha' 'Porter, Mr. Walter Chamberlain'
     'Zabour, Miss. Hileni' 'Barton, Mr. David John' 'Jussila, Miss. Katriina'
     'Attalah, Miss. Malake' 'Pekoniemi, Mr. Edvard' 'Connors, Mr. Patrick'
     'Turpin, Mr. William John Robert' 'Baxter, Mr. Quigg Edmond'
     'Andersson, Miss. Ellis Anna Maria' 'Hickman, Mr. Stanley George'
     'Moore, Mr. Leonard Charles' 'Nasser, Mr. Nicholas' 'Webber, Miss. Susan'
     'White, Mr. Percival Wayland' 'Nicola-Yarred, Master. Elias'
     'McMahon, Mr. Martin' 'Madsen, Mr. Fridtjof Arne' 'Peter, Miss. Anna'
     'Ekstrom, Mr. Johan' 'Drazenoic, Mr. Jozef'
     'Coelho, Mr. Domingos Fernandeo'
     'Robins, Mrs. Alexander A (Grace Charity Laury)'
     'Weisz, Mrs. Leopold (Mathilde Francoise Pede)'
     'Sobey, Mr. Samuel James Hayden' 'Richard, Mr. Emile'
     'Newsom, Miss. Helen Monypeny' 'Futrelle, Mr. Jacques Heath'
     'Osen, Mr. Olaf Elon' 'Giglio, Mr. Victor'
     'Boulos, Mrs. Joseph (Sultana)' 'Nysten, Miss. Anna Sofia'
     'Hakkarainen, Mrs. Pekka Pietari (Elin Matilda Dolck)'
     'Burke, Mr. Jeremiah' 'Andrew, Mr. Edgardo Samuel'
     'Nicholls, Mr. Joseph Charles'
     'Andersson, Mr. August Edvard ("Wennerstrom")'
     'Ford, Miss. Robina Maggie "Ruby"'
     'Navratil, Mr. Michel ("Louis M Hoffman")'
     'Byles, Rev. Thomas Roussel Davids' 'Bateman, Rev. Robert James'
     'Pears, Mrs. Thomas (Edith Wearne)' 'Meo, Mr. Alfonzo'
     'van Billiard, Mr. Austin Blyler' 'Olsen, Mr. Ole Martin'
     'Williams, Mr. Charles Duane' 'Gilnagh, Miss. Katherine "Katie"'
     'Corn, Mr. Harry' 'Smiljanic, Mr. Mile' 'Sage, Master. Thomas Henry'
     'Cribb, Mr. John Hatfield'
     'Watt, Mrs. James (Elizabeth "Bessie" Inglis Milne)'
     'Bengtsson, Mr. John Viktor' 'Calic, Mr. Jovo'
     'Panula, Master. Eino Viljami'
     'Goldsmith, Master. Frank John William "Frankie"'
     'Chibnall, Mrs. (Edith Martha Bowerman)'
     'Skoog, Mrs. William (Anna Bernhardina Karlsson)' 'Baumann, Mr. John D'
     'Ling, Mr. Lee' 'Van der hoef, Mr. Wyckoff' 'Rice, Master. Arthur'
     'Johnson, Miss. Eleanor Ileen' 'Sivola, Mr. Antti Wilhelm'
     'Smith, Mr. James Clinch' 'Klasen, Mr. Klas Albin'
     'Lefebre, Master. Henry Forbes' 'Isham, Miss. Ann Elizabeth'
     'Hale, Mr. Reginald' 'Leonard, Mr. Lionel' 'Sage, Miss. Constance Gladys'
     'Pernot, Mr. Rene' 'Asplund, Master. Clarence Gustaf Hugo'
     'Becker, Master. Richard F' 'Kink-Heilmann, Miss. Luise Gretchen'
     'Rood, Mr. Hugh Roscoe'
     'O\'Brien, Mrs. Thomas (Johanna "Hannah" Godfrey)'
     'Romaine, Mr. Charles Hallace ("Mr C Rolmane")' 'Bourke, Mr. John'
     'Turcin, Mr. Stjepan' 'Pinsky, Mrs. (Rosa)' 'Carbines, Mr. William'
     'Andersen-Jensen, Miss. Carla Christine Nielsine'
     'Navratil, Master. Michel M' 'Brown, Mrs. James Joseph (Margaret Tobin)'
     'Lurette, Miss. Elise' 'Mernagh, Mr. Robert'
     'Olsen, Mr. Karl Siegwart Andreas' 'Madigan, Miss. Margaret "Maggie"'
     'Yrois, Miss. Henriette ("Mrs Harbeck")' 'Vande Walle, Mr. Nestor Cyriel'
     'Sage, Mr. Frederick' 'Johanson, Mr. Jakob Alfred' 'Youseff, Mr. Gerious'
     'Cohen, Mr. Gurshon "Gus"' 'Strom, Miss. Telma Matilda'
     'Backstrom, Mr. Karl Alfred' 'Albimona, Mr. Nassef Cassem'
     'Carr, Miss. Helen "Ellen"' 'Blank, Mr. Henry' 'Ali, Mr. Ahmed'
     'Cameron, Miss. Clear Annie' 'Perkin, Mr. John Henry'
     'Givard, Mr. Hans Kristensen' 'Kiernan, Mr. Philip'
     'Newell, Miss. Madeleine' 'Honkanen, Miss. Eliina'
     'Jacobsohn, Mr. Sidney Samuel' 'Bazzani, Miss. Albina'
     'Harris, Mr. Walter' 'Sunderland, Mr. Victor Francis'
     'Bracken, Mr. James H' 'Green, Mr. George Henry' 'Nenkoff, Mr. Christo'
     'Hoyt, Mr. Frederick Maxfield' 'Berglund, Mr. Karl Ivar Sven'
     'Mellors, Mr. William John' 'Lovell, Mr. John Hall ("Henry")'
     'Fahlstrom, Mr. Arne Jonas' 'Lefebre, Miss. Mathilde'
     'Harris, Mrs. Henry Birkhardt (Irene Wallach)' 'Larsson, Mr. Bengt Edvin'
     'Sjostedt, Mr. Ernst Adolf' 'Asplund, Miss. Lillian Gertrud'
     'Leyson, Mr. Robert William Norman' 'Harknett, Miss. Alice Phoebe'
     'Hold, Mr. Stephen' 'Collyer, Miss. Marjorie "Lottie"'
     'Pengelly, Mr. Frederick William' 'Hunt, Mr. George Henry'
     'Zabour, Miss. Thamine' 'Murphy, Miss. Katherine "Kate"'
     'Coleridge, Mr. Reginald Charles' 'Maenpaa, Mr. Matti Alexanteri'
     'Attalah, Mr. Sleiman' 'Minahan, Dr. William Edward'
     'Lindahl, Miss. Agda Thorilda Viktoria' 'Hamalainen, Mrs. William (Anna)'
     'Beckwith, Mr. Richard Leonard' 'Carter, Rev. Ernest Courtenay'
     'Reed, Mr. James George' 'Strom, Mrs. Wilhelm (Elna Matilda Persson)'
     'Stead, Mr. William Thomas' 'Lobb, Mr. William Arthur'
     'Rosblom, Mrs. Viktor (Helena Wilhelmina)'
     'Touma, Mrs. Darwis (Hanne Youssef Razi)'
     'Thorne, Mrs. Gertrude Maybelle' 'Cherry, Miss. Gladys'
     'Ward, Miss. Anna' 'Parrish, Mrs. (Lutie Davis)' 'Smith, Mr. Thomas'
     'Asplund, Master. Edvin Rojj Felix' 'Taussig, Mr. Emil'
     'Harrison, Mr. William' 'Henry, Miss. Delia' 'Reeves, Mr. David'
     'Panula, Mr. Ernesti Arvid' 'Persson, Mr. Ernst Ulrik'
     'Graham, Mrs. William Thompson (Edith Junkins)' 'Bissette, Miss. Amelia'
     'Cairns, Mr. Alexander' 'Tornquist, Mr. William Henry'
     'Mellinger, Mrs. (Elizabeth Anne Maidment)' 'Natsch, Mr. Charles H'
     'Healy, Miss. Hanora "Nora"' 'Andrews, Miss. Kornelia Theodosia'
     'Lindblom, Miss. Augusta Charlotta' 'Parkes, Mr. Francis "Frank"'
     'Rice, Master. Eric' 'Abbott, Mrs. Stanton (Rosa Hunt)'
     'Duane, Mr. Frank' 'Olsson, Mr. Nils Johan Goransson'
     'de Pelsmaeker, Mr. Alfons' 'Dorking, Mr. Edward Arthur'
     'Smith, Mr. Richard William' 'Stankovic, Mr. Ivan'
     'de Mulder, Mr. Theodore' 'Naidenoff, Mr. Penko' 'Hosono, Mr. Masabumi'
     'Connolly, Miss. Kate' 'Barber, Miss. Ellen "Nellie"'
     'Bishop, Mrs. Dickinson H (Helen Walton)' 'Levy, Mr. Rene Jacques'
     'Haas, Miss. Aloisia' 'Mineff, Mr. Ivan' 'Lewy, Mr. Ervin G'
     'Hanna, Mr. Mansour' 'Allison, Miss. Helen Loraine'
     'Saalfeld, Mr. Adolphe' 'Baxter, Mrs. James (Helene DeLaudeniere Chaput)'
     'Kelly, Miss. Anna Katherine "Annie Kate"' 'McCoy, Mr. Bernard'
     'Johnson, Mr. William Cahoone Jr' 'Keane, Miss. Nora A'
     'Williams, Mr. Howard Hugh "Harry"' 'Allison, Master. Hudson Trevor'
     'Fleming, Miss. Margaret'
     'Penasco y Castellana, Mrs. Victor de Satode (Maria Josefa Perez de Soto y Vallejo)'
     'Abelson, Mr. Samuel' 'Francatelli, Miss. Laura Mabel'
     'Hays, Miss. Margaret Bechstein' 'Ryerson, Miss. Emily Borie'
     'Lahtinen, Mrs. William (Anna Sylfven)' 'Hendekovic, Mr. Ignjac'
     'Hart, Mr. Benjamin' 'Nilsson, Miss. Helmina Josefina'
     'Kantor, Mrs. Sinai (Miriam Sternin)' 'Moraweck, Dr. Ernest'
     'Wick, Miss. Mary Natalie'
     'Spedden, Mrs. Frederic Oakley (Margaretta Corning Stone)'
     'Dennis, Mr. Samuel' 'Danoff, Mr. Yoto' 'Slayter, Miss. Hilda Mary'
     'Caldwell, Mrs. Albert Francis (Sylvia Mae Harbaugh)'
     'Sage, Mr. George John Jr' 'Young, Miss. Marie Grice'
     'Nysveen, Mr. Johan Hansen' 'Ball, Mrs. (Ada E Hall)'
     'Goldsmith, Mrs. Frank John (Emily Alice Brown)'
     'Hippach, Miss. Jean Gertrude' 'McCoy, Miss. Agnes' 'Partner, Mr. Austen'
     'Graham, Mr. George Edward' 'Vander Planke, Mr. Leo Edmondus'
     'Frauenthal, Mrs. Henry William (Clara Heinsheimer)' 'Denkoff, Mr. Mitto'
     'Pears, Mr. Thomas Clinton' 'Burns, Miss. Elizabeth Margaret'
     'Dahl, Mr. Karl Edwart' 'Blackwell, Mr. Stephen Weart'
     'Navratil, Master. Edmond Roger' 'Fortune, Miss. Alice Elizabeth'
     'Collander, Mr. Erik Gustaf' 'Sedgwick, Mr. Charles Frederick Waddington'
     'Fox, Mr. Stanley Hubert' 'Brown, Miss. Amelia "Mildred"'
     'Smith, Miss. Marion Elsie' 'Davison, Mrs. Thomas Henry (Mary E Finck)'
     'Coutts, Master. William Loch "William"' 'Dimic, Mr. Jovan'
     'Odahl, Mr. Nils Martin' 'Williams-Lambert, Mr. Fletcher Fellows'
     'Elias, Mr. Tannous' 'Arnold-Franchi, Mr. Josef' 'Yousif, Mr. Wazli'
     'Vanden Steen, Mr. Leo Peter' 'Bowerman, Miss. Elsie Edith'
     'Funk, Miss. Annie Clemmer' 'McGovern, Miss. Mary'
     'Mockler, Miss. Helen Mary "Ellie"' 'Skoog, Mr. Wilhelm'
     'del Carlo, Mr. Sebastiano' 'Barbara, Mrs. (Catherine David)'
     'Asim, Mr. Adola' "O'Brien, Mr. Thomas" 'Adahl, Mr. Mauritz Nils Martin'
     'Warren, Mrs. Frank Manley (Anna Sophia Atkinson)'
     'Moussa, Mrs. (Mantoura Boulos)' 'Jermyn, Miss. Annie'
     'Aubart, Mme. Leontine Pauline' 'Harder, Mr. George Achilles'
     'Wiklund, Mr. Jakob Alfred' 'Beavan, Mr. William Thomas'
     'Ringhini, Mr. Sante' 'Palsson, Miss. Stina Viola'
     'Meyer, Mrs. Edgar Joseph (Leila Saks)' 'Landergren, Miss. Aurora Adelia'
     'Widener, Mr. Harry Elkins' 'Betros, Mr. Tannous'
     'Gustafsson, Mr. Karl Gideon' 'Bidois, Miss. Rosalie'
     'Nakid, Miss. Maria ("Mary")' 'Tikkanen, Mr. Juho'
     'Holverson, Mrs. Alexander Oskar (Mary Aline Towner)'
     'Plotcharsky, Mr. Vasil' 'Davies, Mr. Charles Henry'
     'Goodwin, Master. Sidney Leonard' 'Buss, Miss. Kate'
     'Sadlier, Mr. Matthew' 'Lehmann, Miss. Bertha'
     'Carter, Mr. William Ernest' 'Jansson, Mr. Carl Olof'
     'Gustafsson, Mr. Johan Birger' 'Newell, Miss. Marjorie'
     'Sandstrom, Mrs. Hjalmar (Agnes Charlotta Bengtsson)'
     'Johansson, Mr. Erik' 'Olsson, Miss. Elina' 'McKane, Mr. Peter David'
     'Pain, Dr. Alfred' 'Trout, Mrs. William H (Jessie L)'
     'Niskanen, Mr. Juha' 'Adams, Mr. John' 'Jussila, Miss. Mari Aina'
     'Hakkarainen, Mr. Pekka Pietari' 'Oreskovic, Miss. Marija'
     'Gale, Mr. Shadrach' 'Widegren, Mr. Carl/Charles Peter'
     'Richards, Master. William Rowe' 'Birkeland, Mr. Hans Martin Monsen'
     'Lefebre, Miss. Ida' 'Sdycoff, Mr. Todor' 'Hart, Mr. Henry'
     'Minahan, Miss. Daisy E' 'Cunningham, Mr. Alfred Fleming'
     'Sundman, Mr. Johan Julian' 'Meek, Mrs. Thomas (Annie Louise Rowley)'
     'Drew, Mrs. James Vivian (Lulu Thorne Christian)'
     'Silven, Miss. Lyyli Karoliina' 'Matthews, Mr. William John'
     'Van Impe, Miss. Catharina' 'Gheorgheff, Mr. Stanio'
     'Charters, Mr. David' 'Zimmerman, Mr. Leo'
     'Danbom, Mrs. Ernst Gilbert (Anna Sigrid Maria Brogren)'
     'Rosblom, Mr. Viktor Richard' 'Wiseman, Mr. Phillippe'
     'Clarke, Mrs. Charles V (Ada Maria Winfield)'
     'Phillips, Miss. Kate Florence ("Mrs Kate Louise Phillips Marshall")'
     'Flynn, Mr. James' 'Pickard, Mr. Berk (Berk Trembisky)'
     'Bjornstrom-Steffansson, Mr. Mauritz Hakan'
     'Thorneycroft, Mrs. Percival (Florence Kate White)'
     'Louch, Mrs. Charles Alexander (Alice Adelaide Slow)'
     'Kallio, Mr. Nikolai Erland' 'Silvey, Mr. William Baird'
     'Carter, Miss. Lucile Polk' 'Ford, Miss. Doolina Margaret "Daisy"'
     'Richards, Mrs. Sidney (Emily Hocking)' 'Fortune, Mr. Mark'
     'Kvillner, Mr. Johan Henrik Johannesson'
     'Hart, Mrs. Benjamin (Esther Ada Bloomfield)' 'Hampe, Mr. Leon'
     'Petterson, Mr. Johan Emil' 'Reynaldo, Ms. Encarnacion'
     'Johannesen-Bratthammer, Mr. Bernt' 'Dodge, Master. Washington'
     'Mellinger, Miss. Madeleine Violet' 'Seward, Mr. Frederic Kimber'
     'Baclini, Miss. Marie Catherine' 'Peuchen, Major. Arthur Godfrey'
     'West, Mr. Edwy Arthur' 'Hagland, Mr. Ingvald Olai Olsen'
     'Foreman, Mr. Benjamin Laventall' 'Goldenberg, Mr. Samuel L'
     'Peduzzi, Mr. Joseph' 'Jalsevac, Mr. Ivan' 'Millet, Mr. Francis Davis'
     'Kenyon, Mrs. Frederick R (Marion)' 'Toomey, Miss. Ellen'
     "O'Connor, Mr. Maurice" 'Anderson, Mr. Harry' 'Morley, Mr. William'
     'Gee, Mr. Arthur H' 'Milling, Mr. Jacob Christian' 'Maisner, Mr. Simon'
     'Goncalves, Mr. Manuel Estanslas' 'Campbell, Mr. William'
     'Smart, Mr. John Montgomery' 'Scanlan, Mr. James'
     'Baclini, Miss. Helene Barbara' 'Keefe, Mr. Arthur' 'Cacic, Mr. Luka'
     'West, Mrs. Edwy Arthur (Ada Mary Worth)'
     'Jerwan, Mrs. Amin S (Marie Marthe Thuillard)'
     'Strandberg, Miss. Ida Sofia' 'Clifford, Mr. George Quincy'
     'Renouf, Mr. Peter Henry' 'Braund, Mr. Lewis Richard'
     'Karlsson, Mr. Nils August' 'Hirvonen, Miss. Hildur E'
     'Goodwin, Master. Harold Victor' 'Frost, Mr. Anthony Wood "Archie"'
     'Rouse, Mr. Richard Henry' 'Turkula, Mrs. (Hedwig)'
     'Bishop, Mr. Dickinson H' 'Lefebre, Miss. Jeannie'
     'Hoyt, Mrs. Frederick Maxfield (Jane Anne Forby)'
     'Kent, Mr. Edward Austin' 'Somerton, Mr. Francis William'
     'Coutts, Master. Eden Leslie "Neville"'
     'Hagland, Mr. Konrad Mathias Reiersen' 'Windelov, Mr. Einar'
     'Molson, Mr. Harry Markland' 'Artagaveytia, Mr. Ramon'
     'Stanley, Mr. Edward Roland' 'Yousseff, Mr. Gerious'
     'Eustis, Miss. Elizabeth Mussey' 'Shellard, Mr. Frederick William'
     'Allison, Mrs. Hudson J C (Bessie Waldo Daniels)' 'Svensson, Mr. Olof'
     'Calic, Mr. Petar' 'Canavan, Miss. Mary' "O'Sullivan, Miss. Bridget Mary"
     'Laitinen, Miss. Kristina Sofia' 'Maioni, Miss. Roberta'
     'Penasco y Castellana, Mr. Victor de Satode'
     'Quick, Mrs. Frederick Charles (Jane Richards)'
     'Bradley, Mr. George ("George Arthur Brayton")'
     'Olsen, Mr. Henry Margido' 'Lang, Mr. Fang' 'Daly, Mr. Eugene Patrick'
     'Webber, Mr. James' 'McGough, Mr. James Robert'
     'Rothschild, Mrs. Martin (Elizabeth L. Barrett)' 'Coleff, Mr. Satio'
     'Walker, Mr. William Anderson' 'Lemore, Mrs. (Amelia Milley)'
     'Ryan, Mr. Patrick'
     'Angle, Mrs. William A (Florence "Mary" Agnes Hughes)'
     'Pavlovic, Mr. Stefo' 'Perreault, Miss. Anne' 'Vovk, Mr. Janko'
     'Lahoud, Mr. Sarkis' 'Hippach, Mrs. Louis Albert (Ida Sophia Fischer)'
     'Kassem, Mr. Fared' 'Farrell, Mr. James' 'Ridsdale, Miss. Lucy'
     'Farthing, Mr. John' 'Salonen, Mr. Johan Werner'
     'Hocking, Mr. Richard George' 'Quick, Miss. Phyllis May'
     'Toufik, Mr. Nakli' 'Elias, Mr. Joseph Jr'
     'Peter, Mrs. Catherine (Catherine Rizk)' 'Cacic, Miss. Marija'
     'Hart, Miss. Eva Miriam' 'Butt, Major. Archibald Willingham'
     'LeRoy, Miss. Bertha' 'Risien, Mr. Samuel Beard'
     'Frolicher, Miss. Hedwig Margaritha' 'Crosby, Miss. Harriet R'
     'Andersson, Miss. Ingeborg Constanzia'
     'Andersson, Miss. Sigrid Elisabeth' 'Beane, Mr. Edward'
     'Douglas, Mr. Walter Donald' 'Nicholson, Mr. Arthur Ernest'
     'Beane, Mrs. Edward (Ethel Clarke)' 'Padro y Manent, Mr. Julian'
     'Goldsmith, Mr. Frank John' 'Davies, Master. John Morgan Jr'
     'Thayer, Mr. John Borland Jr' 'Sharp, Mr. Percival James R'
     "O'Brien, Mr. Timothy" 'Leeni, Mr. Fahim ("Philip Zenni")'
     'Ohman, Miss. Velin' 'Wright, Mr. George'
     'Duff Gordon, Lady. (Lucille Christiana Sutherland) ("Mrs Morgan")'
     'Robbins, Mr. Victor' 'Taussig, Mrs. Emil (Tillie Mandelbaum)'
     'de Messemaeker, Mrs. Guillaume Joseph (Emma)' 'Morrow, Mr. Thomas Rowan'
     'Sivic, Mr. Husein' 'Norman, Mr. Robert Douglas' 'Simmons, Mr. John'
     'Meanwell, Miss. (Marion Ogden)' 'Davies, Mr. Alfred J'
     'Stoytcheff, Mr. Ilia' 'Palsson, Mrs. Nils (Alma Cornelia Berglund)'
     'Doharr, Mr. Tannous' 'Jonsson, Mr. Carl' 'Harris, Mr. George'
     'Appleton, Mrs. Edward Dale (Charlotte Lamson)'
     'Flynn, Mr. John Irwin ("Irving")' 'Kelly, Miss. Mary'
     'Rush, Mr. Alfred George John' 'Patchett, Mr. George'
     'Garside, Miss. Ethel' 'Silvey, Mrs. William Baird (Alice Munger)'
     'Caram, Mrs. Joseph (Maria Elias)' 'Jussila, Mr. Eiriik'
     'Christy, Miss. Julie Rachel'
     'Thayer, Mrs. John Borland (Marian Longstreth Morris)'
     'Downton, Mr. William James' 'Ross, Mr. John Hugo' 'Paulner, Mr. Uscher'
     'Taussig, Miss. Ruth' 'Jarvis, Mr. John Denzil'
     'Frolicher-Stehli, Mr. Maxmillian' 'Gilinski, Mr. Eliezer'
     'Murdlin, Mr. Joseph' 'Rintamaki, Mr. Matti'
     'Stephenson, Mrs. Walter Bertram (Martha Eustis)'
     'Elsbury, Mr. William James' 'Bourke, Miss. Mary'
     'Chapman, Mr. John Henry' 'Van Impe, Mr. Jean Baptiste'
     'Leitch, Miss. Jessie Wills' 'Johnson, Mr. Alfred' 'Boulos, Mr. Hanna'
     'Duff Gordon, Sir. Cosmo Edmund ("Mr Morgan")'
     'Jacobsohn, Mrs. Sidney Samuel (Amy Frances Christy)'
     'Slabenoff, Mr. Petco' 'Harrington, Mr. Charles H'
     'Torber, Mr. Ernst William' 'Homer, Mr. Harry ("Mr E Haven")'
     'Lindell, Mr. Edvard Bengtsson' 'Karaic, Mr. Milan'
     'Daniel, Mr. Robert Williams'
     'Laroche, Mrs. Joseph (Juliette Marie Louise Lafargue)'
     'Shutes, Miss. Elizabeth W'
     'Andersson, Mrs. Anders Johan (Alfrida Konstantia Brogren)'
     'Jardin, Mr. Jose Neto' 'Murphy, Miss. Margaret Jane' 'Horgan, Mr. John'
     'Brocklebank, Mr. William Alfred' 'Herman, Miss. Alice'
     'Danbom, Mr. Ernst Gilbert'
     'Lobb, Mrs. William Arthur (Cordelia K Stanlick)'
     'Becker, Miss. Marion Louise' 'Gavey, Mr. Lawrence' 'Yasbeck, Mr. Antoni'
     'Kimball, Mr. Edwin Nelson Jr' 'Nakid, Mr. Sahid'
     'Hansen, Mr. Henry Damsgaard' 'Bowen, Mr. David John "Dai"'
     'Sutton, Mr. Frederick' 'Kirkland, Rev. Charles Leonard'
     'Longley, Miss. Gretchen Fiske' 'Bostandyeff, Mr. Guentcho'
     "O'Connell, Mr. Patrick D" 'Barkworth, Mr. Algernon Henry Wilson'
     'Lundahl, Mr. Johan Svensson' 'Stahelin-Maeglin, Dr. Max'
     'Parr, Mr. William Henry Marsh' 'Skoog, Miss. Mabel' 'Davis, Miss. Mary'
     'Leinonen, Mr. Antti Gustaf' 'Collyer, Mr. Harvey'
     'Panula, Mrs. Juha (Maria Emilia Ojala)' 'Thorneycroft, Mr. Percival'
     'Jensen, Mr. Hans Peder' 'Sagesser, Mlle. Emma'
     'Skoog, Miss. Margit Elizabeth' 'Foo, Mr. Choong'
     'Baclini, Miss. Eugenie' 'Harper, Mr. Henry Sleeper' 'Cor, Mr. Liudevit'
     'Simonius-Blumer, Col. Oberst Alfons' 'Willey, Mr. Edward'
     'Stanley, Miss. Amy Zillah Elsie' 'Mitkoff, Mr. Mito'
     'Doling, Miss. Elsie' 'Kalvik, Mr. Johannes Halvorsen'
     'O\'Leary, Miss. Hanora "Norah"' 'Hegarty, Miss. Hanora "Nora"'
     'Hickman, Mr. Leonard Mark' 'Radeff, Mr. Alexander'
     'Bourke, Mrs. John (Catherine)' 'Eitemiller, Mr. George Floyd'
     'Newell, Mr. Arthur Webster' 'Frauenthal, Dr. Henry William'
     'Badt, Mr. Mohamed' 'Colley, Mr. Edward Pomeroy' 'Coleff, Mr. Peju'
     'Lindqvist, Mr. Eino William' 'Hickman, Mr. Lewis'
     'Butler, Mr. Reginald Fenton' 'Rommetvedt, Mr. Knud Paust'
     'Cook, Mr. Jacob' 'Taylor, Mrs. Elmer Zebley (Juliet Cummins Wright)'
     'Brown, Mrs. Thomas William Solomon (Elizabeth Catherine Ford)'
     'Davidson, Mr. Thornton' 'Mitchell, Mr. Henry Michael'
     'Wilhelms, Mr. Charles' 'Watson, Mr. Ennis Hastings'
     'Edvardsson, Mr. Gustaf Hjalmar' 'Sawyer, Mr. Frederick Charles'
     'Turja, Miss. Anna Sofia' 'Goodwin, Mrs. Frederick (Augusta Tyler)'
     'Cardeza, Mr. Thomas Drake Martinez' 'Peters, Miss. Katie'
     'Hassab, Mr. Hammad' 'Olsvigen, Mr. Thor Anderson'
     'Goodwin, Mr. Charles Edward' 'Brown, Mr. Thomas William Solomon'
     'Laroche, Mr. Joseph Philippe Lemercier' 'Panula, Mr. Jaako Arnold'
     'Dakic, Mr. Branko' 'Fischer, Mr. Eberhard Thelander'
     'Madill, Miss. Georgette Alexandra' 'Dick, Mr. Albert Adrian'
     'Karun, Miss. Manca' 'Lam, Mr. Ali' 'Saad, Mr. Khalil' 'Weir, Col. John'
     'Chapman, Mr. Charles Henry' 'Kelly, Mr. James'
     'Mullens, Miss. Katherine "Katie"' 'Thayer, Mr. John Borland'
     'Humblen, Mr. Adolf Mathias Nicolai Olsen'
     'Astor, Mrs. John Jacob (Madeleine Talmadge Force)'
     'Silverthorne, Mr. Spencer Victor' 'Barbara, Miss. Saiide'
     'Gallagher, Mr. Martin' 'Hansen, Mr. Henrik Juul'
     'Morley, Mr. Henry Samuel ("Mr Henry Marshall")'
     'Kelly, Mrs. Florence "Fannie"' 'Calderhead, Mr. Edward Pennington'
     'Cleaver, Miss. Alice'
     'Moubarek, Master. Halim Gonios ("William George")'
     'Mayne, Mlle. Berthe Antonine ("Mrs de Villiers")' 'Klaber, Mr. Herman'
     'Taylor, Mr. Elmer Zebley' 'Larsson, Mr. August Viktor'
     'Greenberg, Mr. Samuel' 'Soholt, Mr. Peter Andreas Lauritz Andersen'
     'Endres, Miss. Caroline Louise' 'Troutt, Miss. Edwina Celia "Winnie"'
     'McEvoy, Mr. Michael' 'Johnson, Mr. Malkolm Joackim'
     'Harper, Miss. Annie Jessie "Nina"' 'Jensen, Mr. Svend Lauritz'
     'Gillespie, Mr. William Henry' 'Hodges, Mr. Henry Price'
     'Chambers, Mr. Norman Campbell' 'Oreskovic, Mr. Luka'
     'Renouf, Mrs. Peter Henry (Lillian Jefferys)' 'Mannion, Miss. Margareth'
     'Bryhl, Mr. Kurt Arnold Gottfrid' 'Ilmakangas, Miss. Pieta Sofia'
     'Allen, Miss. Elisabeth Walton' 'Hassan, Mr. Houssein G N'
     'Knight, Mr. Robert J' 'Berriman, Mr. William John'
     'Troupiansky, Mr. Moses Aaron' 'Williams, Mr. Leslie'
     'Ford, Mrs. Edward (Margaret Ann Watson)' 'Lesurer, Mr. Gustave J'
     'Ivanoff, Mr. Kanio' 'Nankoff, Mr. Minko' 'Hawksford, Mr. Walter James'
     'Cavendish, Mr. Tyrell William' 'Ryerson, Miss. Susan Parker "Suzette"'
     'McNamee, Mr. Neal' 'Stranden, Mr. Juho' 'Crosby, Capt. Edward Gifford'
     'Abbott, Mr. Rossmore Edward' 'Sinkkonen, Miss. Anna'
     'Marvin, Mr. Daniel Warner' 'Connaghton, Mr. Michael' 'Wells, Miss. Joan'
     'Moor, Master. Meier' 'Vande Velde, Mr. Johannes Joseph'
     'Jonkoff, Mr. Lalio' 'Herman, Mrs. Samuel (Jane Laver)'
     'Hamalainen, Master. Viljo' 'Carlsson, Mr. August Sigfrid'
     'Bailey, Mr. Percy Andrew' 'Theobald, Mr. Thomas Leonard'
     'Rothes, the Countess. of (Lucy Noel Martha Dyer-Edwards)'
     'Garfirth, Mr. John' 'Nirva, Mr. Iisakki Antino Aijo'
     'Barah, Mr. Hanna Assi' 'Carter, Mrs. William Ernest (Lucile Polk)'
     'Eklund, Mr. Hans Linus' 'Hogeboom, Mrs. John C (Anna Andrews)'
     'Brewe, Dr. Arthur Jackson' 'Mangan, Miss. Mary' 'Moran, Mr. Daniel J'
     'Gronnestad, Mr. Daniel Danielsen' 'Lievens, Mr. Rene Aime'
     'Jensen, Mr. Niels Peder' 'Mack, Mrs. (Mary)' 'Elias, Mr. Dibo'
     'Hocking, Mrs. Elizabeth (Eliza Needs)'
     'Myhrman, Mr. Pehr Fabian Oliver Malkolm' 'Tobin, Mr. Roger'
     'Emanuel, Miss. Virginia Ethel' 'Kilgannon, Mr. Thomas J'
     'Robert, Mrs. Edward Scott (Elisabeth Walton McMillan)'
     'Ayoub, Miss. Banoura' 'Dick, Mrs. Albert Adrian (Vera Gillespie)'
     'Long, Mr. Milton Clyde' 'Johnston, Mr. Andrew G' 'Ali, Mr. William'
     'Harmer, Mr. Abraham (David Lishin)' 'Sjoblom, Miss. Anna Sofia'
     'Rice, Master. George Hugh' 'Dean, Master. Bertram Vere'
     'Guggenheim, Mr. Benjamin' 'Keane, Mr. Andrew "Andy"'
     'Gaskell, Mr. Alfred' 'Sage, Miss. Stella Anna'
     'Hoyt, Mr. William Fisher' 'Dantcheff, Mr. Ristiu' 'Otter, Mr. Richard'
     'Leader, Dr. Alice (Farnham)' 'Osman, Mrs. Mara'
     'Ibrahim Shawah, Mr. Yousseff'
     'Van Impe, Mrs. Jean Baptiste (Rosalie Paula Govaert)'
     'Ponesell, Mr. Martin' 'Collyer, Mrs. Harvey (Charlotte Annie Tate)'
     'Carter, Master. William Thornton II' 'Thomas, Master. Assad Alexander'
     'Hedman, Mr. Oskar Arvid' 'Johansson, Mr. Karl Johan'
     'Andrews, Mr. Thomas Jr' 'Pettersson, Miss. Ellen Natalia'
     'Meyer, Mr. August' 'Chambers, Mrs. Norman Campbell (Bertha Griggs)'
     'Alexander, Mr. William' 'Lester, Mr. James' 'Slemen, Mr. Richard James'
     'Andersson, Miss. Ebba Iris Alfrida' 'Tomlin, Mr. Ernest Portage'
     'Fry, Mr. Richard' 'Heininen, Miss. Wendla Maria' 'Mallet, Mr. Albert'
     'Holm, Mr. John Fredrik Alexander' 'Skoog, Master. Karl Thorsten'
     'Hays, Mrs. Charles Melville (Clara Jennings Gregg)' 'Lulic, Mr. Nikola'
     'Reuchlin, Jonkheer. John George' 'Moor, Mrs. (Beila)'
     'Panula, Master. Urho Abraham' 'Flynn, Mr. John' 'Lam, Mr. Len'
     'Mallet, Master. Andre' 'McCormack, Mr. Thomas Joseph'
     'Stone, Mrs. George Nelson (Martha Evelyn)'
     'Yasbeck, Mrs. Antoni (Selini Alexander)'
     'Richards, Master. George Sibley' 'Saad, Mr. Amin'
     'Augustsson, Mr. Albert' 'Allum, Mr. Owen George'
     'Compton, Miss. Sara Rebecca' 'Pasic, Mr. Jakob' 'Sirota, Mr. Maurice'
     'Chip, Mr. Chang' 'Marechal, Mr. Pierre' 'Alhomaki, Mr. Ilmari Rudolf'
     'Mudd, Mr. Thomas Charles' 'Serepeca, Miss. Augusta'
     'Lemberopolous, Mr. Peter L' 'Culumovic, Mr. Jeso' 'Abbing, Mr. Anthony'
     'Sage, Mr. Douglas Bullen' 'Markoff, Mr. Marin' 'Harper, Rev. John'
     'Goldenberg, Mrs. Samuel L (Edwiga Grabowska)'
     'Andersson, Master. Sigvard Harald Elias' 'Svensson, Mr. Johan'
     'Boulos, Miss. Nourelain' 'Lines, Miss. Mary Conover'
     'Carter, Mrs. Ernest Courtenay (Lilian Hughes)'
     'Aks, Mrs. Sam (Leah Rosen)' 'Wick, Mrs. George Dennick (Mary Hitchcock)'
     'Daly, Mr. Peter Denis ' 'Baclini, Mrs. Solomon (Latifa Qurban)'
     'Razi, Mr. Raihed' 'Hansen, Mr. Claus Peter'
     'Giles, Mr. Frederick Edward'
     'Swift, Mrs. Frederick Joel (Margaret Welles Barron)'
     'Sage, Miss. Dorothy Edith "Dolly"' 'Gill, Mr. John William'
     'Bystrom, Mrs. (Karolina)' 'Duran y More, Miss. Asuncion'
     'Roebling, Mr. Washington Augustus II' 'van Melkebeke, Mr. Philemon'
     'Johnson, Master. Harold Theodor' 'Balkic, Mr. Cerin'
     'Beckwith, Mrs. Richard Leonard (Sallie Monypeny)'
     'Carlsson, Mr. Frans Olof' 'Vander Cruyssen, Mr. Victor'
     'Abelson, Mrs. Samuel (Hannah Wizosky)'
     'Najib, Miss. Adele Kiamie "Jane"' 'Gustafsson, Mr. Alfred Ossian'
     'Petroff, Mr. Nedelio' 'Laleff, Mr. Kristo'
     'Potter, Mrs. Thomas Jr (Lily Alexenia Wilson)'
     'Shelley, Mrs. William (Imanita Parrish Hall)' 'Markun, Mr. Johann'
     'Dahlberg, Miss. Gerda Ulrika' 'Banfield, Mr. Frederick James'
     'Sutehall, Mr. Henry Jr' 'Rice, Mrs. William (Margaret Norton)'
     'Montvila, Rev. Juozas' 'Graham, Miss. Margaret Edith'
     'Johnston, Miss. Catherine Helen "Carrie"' 'Behr, Mr. Karl Howell'
     'Dooley, Mr. Patrick']
    ['male' 'female']
    [22.   38.   26.   35.   28.   54.    2.   27.   14.    4.   58.   20.
     39.   55.   31.   34.   15.    8.   19.   40.   66.   42.   21.   18.
      3.    7.   49.   29.   65.   28.5   5.   11.   45.   17.   32.   16.
     25.    0.83 30.   33.   23.   24.   46.   59.   71.   37.   47.   14.5
     70.5  32.5  12.    9.   36.5  51.   55.5  40.5  44.    1.   61.   56.
     50.   36.   45.5  20.5  62.   41.   52.   63.   23.5   0.92 43.   60.
     10.   64.   13.   48.    0.75 53.   57.   80.   70.   24.5   6.    0.67
     30.5   0.42 34.5  74.  ]
    [1 0 3 4 2 5 8]
    [0 1 2 5 3 4 6]
    [  7.25    71.2833   7.925   53.1      8.05     8.4583  51.8625  21.075
      11.1333  30.0708  16.7     26.55    31.275    7.8542  16.      29.125
      13.      18.       7.225   26.       8.0292  35.5     31.3875 263.
       7.8792   7.8958  27.7208 146.5208   7.75    10.5     82.1708  52.
       7.2292  11.2417   9.475   21.      41.5792  15.5     21.6792  17.8
      39.6875   7.8     76.7292  61.9792  27.75    46.9     80.      83.475
      27.9     15.2458   8.1583   8.6625  73.5     14.4542  56.4958   7.65
      29.      12.475    9.       9.5      7.7875  47.1     15.85    34.375
      61.175   20.575   34.6542  63.3583  23.      77.2875   8.6542   7.775
      24.15     9.825   14.4583 247.5208   7.1417  22.3583   6.975    7.05
      14.5     15.0458  26.2833   9.2167  79.2      6.75    11.5     36.75
       7.7958  12.525   66.6      7.3125  61.3792   7.7333  69.55    16.1
      15.75    20.525   55.      25.925   33.5     30.6958  25.4667  28.7125
       0.      15.05    39.      22.025   50.       8.4042   6.4958  10.4625
      18.7875  31.     113.275   27.      76.2917  90.       9.35    13.5
       7.55    26.25    12.275    7.125   52.5542  20.2125  86.5    512.3292
      79.65   153.4625 135.6333  19.5     29.7     77.9583  20.25    78.85
      91.0792  12.875    8.85   151.55    30.5     23.25    12.35   110.8833
     108.9     24.      56.9292  83.1583 262.375   14.     164.8667 134.5
       6.2375  57.9792  28.5    133.65    15.9      9.225   35.      75.25
      69.3     55.4417 211.5      4.0125 227.525   15.7417   7.7292  12.
     120.      12.65    18.75     6.8583  32.5      7.875   14.4     55.9
       8.1125  81.8583  19.2583  19.9667  89.1042  38.5      7.725   13.7917
       9.8375   7.0458   7.5208  12.2875   9.5875  49.5042  78.2667  15.1
       7.6292  22.525   26.2875  59.4      7.4958  34.0208  93.5    221.7792
     106.425   49.5     71.      13.8625   7.8292  39.6     17.4     51.4792
      26.3875  30.      40.125    8.7125  15.      33.      42.4     15.55
      65.      32.3208   7.0542   8.4333  25.5875   9.8417   8.1375  10.1708
     211.3375  57.      13.4167   7.7417   9.4833   7.7375   8.3625  23.45
      25.9292   8.6833   8.5167   7.8875  37.0042   6.45     6.95     8.3
       6.4375  39.4     14.1083  13.8583  50.4958   5.       9.8458  10.5167]
    ['B96 B98' 'C85' 'C123' 'E46' 'G6' 'C103' 'D56' 'A6' 'C23 C25 C27' 'B78'
     'D33' 'B30' 'C52' 'B28' 'C83' 'F33' 'F G73' 'E31' 'A5' 'D10 D12' 'D26'
     'C110' 'B58 B60' 'E101' 'F E69' 'D47' 'B86' 'F2' 'C2' 'E33' 'B19' 'A7'
     'C49' 'F4' 'A32' 'B4' 'B80' 'A31' 'D36' 'D15' 'C93' 'C78' 'D35' 'C87'
     'B77' 'E67' 'B94' 'C125' 'C99' 'C118' 'D7' 'A19' 'B49' 'D' 'C22 C26'
     'C106' 'C65' 'E36' 'C54' 'B57 B59 B63 B66' 'C7' 'E34' 'C32' 'B18' 'C124'
     'C91' 'E40' 'T' 'C128' 'D37' 'B35' 'E50' 'C82' 'E10' 'E44' 'A34' 'C104'
     'C111' 'C92' 'E38' 'D21' 'E12' 'E63' 'A14' 'B37' 'C30' 'D20' 'B79' 'E25'
     'D46' 'B73' 'C95' 'B38' 'B39' 'B22' 'C86' 'C70' 'A16' 'C101' 'C68' 'A10'
     'E68' 'B41' 'A20' 'D19' 'D50' 'D9' 'A23' 'B50' 'A26' 'D48' 'E58' 'C126'
     'B71' 'B51 B53 B55' 'D49' 'B5' 'B20' 'F G63' 'C62 C64' 'E24' 'C90' 'C45'
     'E8' 'B101' 'D45' 'C46' 'D30' 'E121' 'D11' 'E77' 'F38' 'B3' 'D6'
     'B82 B84' 'D17' 'A36' 'B102' 'B69' 'E49' 'C47' 'D28' 'E17' 'A24' 'C50'
     'B42' 'C148']
    ['S' 'C' 'Q']
    ['B' 'C' 'E' 'G' 'D' 'A' 'F' 'T']
    


```python
df1.describe().T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Survived</th>
      <td>891.0</td>
      <td>0.383838</td>
      <td>0.486592</td>
      <td>0.00</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>1.0</td>
      <td>1.0000</td>
    </tr>
    <tr>
      <th>Pclass</th>
      <td>891.0</td>
      <td>2.308642</td>
      <td>0.836071</td>
      <td>1.00</td>
      <td>2.0000</td>
      <td>3.0000</td>
      <td>3.0</td>
      <td>3.0000</td>
    </tr>
    <tr>
      <th>Age</th>
      <td>891.0</td>
      <td>29.361582</td>
      <td>13.019697</td>
      <td>0.42</td>
      <td>22.0000</td>
      <td>28.0000</td>
      <td>35.0</td>
      <td>80.0000</td>
    </tr>
    <tr>
      <th>SibSp</th>
      <td>891.0</td>
      <td>0.523008</td>
      <td>1.102743</td>
      <td>0.00</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>1.0</td>
      <td>8.0000</td>
    </tr>
    <tr>
      <th>Parch</th>
      <td>891.0</td>
      <td>0.381594</td>
      <td>0.806057</td>
      <td>0.00</td>
      <td>0.0000</td>
      <td>0.0000</td>
      <td>0.0</td>
      <td>6.0000</td>
    </tr>
    <tr>
      <th>Fare</th>
      <td>891.0</td>
      <td>32.204208</td>
      <td>49.693429</td>
      <td>0.00</td>
      <td>7.9104</td>
      <td>14.4542</td>
      <td>31.0</td>
      <td>512.3292</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1.describe(include="object").T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>unique</th>
      <th>top</th>
      <th>freq</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Name</th>
      <td>891</td>
      <td>891</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Sex</th>
      <td>891</td>
      <td>2</td>
      <td>male</td>
      <td>577</td>
    </tr>
    <tr>
      <th>Cabin</th>
      <td>891</td>
      <td>147</td>
      <td>B96 B98</td>
      <td>691</td>
    </tr>
    <tr>
      <th>Embarked</th>
      <td>891</td>
      <td>3</td>
      <td>S</td>
      <td>646</td>
    </tr>
    <tr>
      <th>cabin_name</th>
      <td>891</td>
      <td>8</td>
      <td>B</td>
      <td>734</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Survived</th>
      <td>1.000000</td>
      <td>-0.338481</td>
      <td>-0.064910</td>
      <td>-0.035322</td>
      <td>0.081629</td>
      <td>0.257307</td>
    </tr>
    <tr>
      <th>Pclass</th>
      <td>-0.338481</td>
      <td>1.000000</td>
      <td>-0.339898</td>
      <td>0.083081</td>
      <td>0.018443</td>
      <td>-0.549500</td>
    </tr>
    <tr>
      <th>Age</th>
      <td>-0.064910</td>
      <td>-0.339898</td>
      <td>1.000000</td>
      <td>-0.233296</td>
      <td>-0.172482</td>
      <td>0.096688</td>
    </tr>
    <tr>
      <th>SibSp</th>
      <td>-0.035322</td>
      <td>0.083081</td>
      <td>-0.233296</td>
      <td>1.000000</td>
      <td>0.414838</td>
      <td>0.159651</td>
    </tr>
    <tr>
      <th>Parch</th>
      <td>0.081629</td>
      <td>0.018443</td>
      <td>-0.172482</td>
      <td>0.414838</td>
      <td>1.000000</td>
      <td>0.216225</td>
    </tr>
    <tr>
      <th>Fare</th>
      <td>0.257307</td>
      <td>-0.549500</td>
      <td>0.096688</td>
      <td>0.159651</td>
      <td>0.216225</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.heatmap(df1.corr());
```


    
![png](output_30_0.png)
    



```python
sns.heatmap(df1.corr(),annot=True);
```


    
![png](output_31_0.png)
    



```python
l=["Survived","Pclass"]
for i in l:
    df1[i]=df1[i].astype("object")
```


```python

```

# EDA


```python
df1["Survived"]=df1["Survived"].astype("object")
```


```python
df1["Pclass"]=df1["Pclass"].astype("object")
```


```python
df1.select_dtypes(include="object").columns
```




    Index(['Survived', 'Pclass', 'Name', 'Sex', 'Cabin', 'Embarked', 'cabin_name'], dtype='object')




```python
df1["Survived"].unique()
```




    array([0, 1], dtype=object)




```python
df1["Survived"].value_counts()
```




    0    549
    1    342
    Name: Survived, dtype: int64




```python
import seaborn as sns
sns.countplot(df1["Survived"])
```

    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    




    <AxesSubplot:xlabel='Survived', ylabel='count'>




    
![png](output_40_2.png)
    



```python
import matplotlib.pyplot as plt
```


```python
l1=["not_Survived","Survived"]
l=list(df1["Survived"].value_counts())
plt.pie(l,labels=l1,autopct="%0.01f%%")
```




    ([<matplotlib.patches.Wedge at 0x2ba80311cd0>,
      <matplotlib.patches.Wedge at 0x2ba8031f430>],
     [Text(-0.3925749350994583, 1.0275626113924428, 'not_Survived'),
      Text(0.3925750313068116, -1.0275625746369201, 'Survived')],
     [Text(-0.21413178278152267, 0.5604886971231505, '61.6%'),
      Text(0.21413183525826085, -0.5604886770746836, '38.4%')])




    
![png](output_42_1.png)
    



```python
l1=["male","female"]
l=list(df1["Sex"].value_counts())
plt.pie(l,labels=l1,autopct="%0.01f%%")
```




    ([<matplotlib.patches.Wedge at 0x2ba8036c370>,
      <matplotlib.patches.Wedge at 0x2ba8036ca90>],
     [Text(-0.4919454136803954, 0.9838646807152012, 'male'),
      Text(0.4919455057964525, -0.9838646346559433, 'female')],
     [Text(-0.2683338620074884, 0.5366534622082915, '64.8%'),
      Text(0.26833391225261044, -0.53665343708506, '35.2%')])




    
![png](output_43_1.png)
    



```python
df1["Embarked"].unique()
```




    array(['S', 'C', 'Q'], dtype=object)




```python

l1=["S","C","Q"]
l=list(df1["Embarked"].value_counts())
plt.pie(l,labels=l1,autopct="%0.01f%%");
```


    
![png](output_45_0.png)
    



```python
df1["cabin_name"].unique()
```




    array(['B', 'C', 'E', 'G', 'D', 'A', 'F', 'T'], dtype=object)




```python
l1=['B', 'C', 'E', 'G', 'D', 'A', 'F', 'T']
l=list(df1["cabin_name"].value_counts())
plt.pie(l,labels=l1,autopct="%0.01f%%");
```


    
![png](output_47_0.png)
    



```python
df1.drop(columns=["Cabin"],inplace=True)
```


```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
      <th>Embarked</th>
      <th>cabin_name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>7.2500</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>71.2833</td>
      <td>C</td>
      <td>C</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>7.9250</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>53.1000</td>
      <td>S</td>
      <td>C</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>8.0500</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>886</th>
      <td>0</td>
      <td>2</td>
      <td>Montvila, Rev. Juozas</td>
      <td>male</td>
      <td>27.0</td>
      <td>0</td>
      <td>0</td>
      <td>13.0000</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>887</th>
      <td>1</td>
      <td>1</td>
      <td>Graham, Miss. Margaret Edith</td>
      <td>female</td>
      <td>19.0</td>
      <td>0</td>
      <td>0</td>
      <td>30.0000</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>888</th>
      <td>0</td>
      <td>3</td>
      <td>Johnston, Miss. Catherine Helen "Carrie"</td>
      <td>female</td>
      <td>28.0</td>
      <td>1</td>
      <td>2</td>
      <td>23.4500</td>
      <td>S</td>
      <td>B</td>
    </tr>
    <tr>
      <th>889</th>
      <td>1</td>
      <td>1</td>
      <td>Behr, Mr. Karl Howell</td>
      <td>male</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>30.0000</td>
      <td>C</td>
      <td>C</td>
    </tr>
    <tr>
      <th>890</th>
      <td>0</td>
      <td>3</td>
      <td>Dooley, Mr. Patrick</td>
      <td>male</td>
      <td>32.0</td>
      <td>0</td>
      <td>0</td>
      <td>7.7500</td>
      <td>Q</td>
      <td>B</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 10 columns</p>
</div>




```python
df1["Name"].unique()
```




    array(['Braund, Mr. Owen Harris',
           'Cumings, Mrs. John Bradley (Florence Briggs Thayer)',
           'Heikkinen, Miss. Laina',
           'Futrelle, Mrs. Jacques Heath (Lily May Peel)',
           'Allen, Mr. William Henry', 'Moran, Mr. James',
           'McCarthy, Mr. Timothy J', 'Palsson, Master. Gosta Leonard',
           'Johnson, Mrs. Oscar W (Elisabeth Vilhelmina Berg)',
           'Nasser, Mrs. Nicholas (Adele Achem)',
           'Sandstrom, Miss. Marguerite Rut', 'Bonnell, Miss. Elizabeth',
           'Saundercock, Mr. William Henry', 'Andersson, Mr. Anders Johan',
           'Vestrom, Miss. Hulda Amanda Adolfina',
           'Hewlett, Mrs. (Mary D Kingcome) ', 'Rice, Master. Eugene',
           'Williams, Mr. Charles Eugene',
           'Vander Planke, Mrs. Julius (Emelia Maria Vandemoortele)',
           'Masselmani, Mrs. Fatima', 'Fynney, Mr. Joseph J',
           'Beesley, Mr. Lawrence', 'McGowan, Miss. Anna "Annie"',
           'Sloper, Mr. William Thompson', 'Palsson, Miss. Torborg Danira',
           'Asplund, Mrs. Carl Oscar (Selma Augusta Emilia Johansson)',
           'Emir, Mr. Farred Chehab', 'Fortune, Mr. Charles Alexander',
           'O\'Dwyer, Miss. Ellen "Nellie"', 'Todoroff, Mr. Lalio',
           'Uruchurtu, Don. Manuel E',
           'Spencer, Mrs. William Augustus (Marie Eugenie)',
           'Glynn, Miss. Mary Agatha', 'Wheadon, Mr. Edward H',
           'Meyer, Mr. Edgar Joseph', 'Holverson, Mr. Alexander Oskar',
           'Mamee, Mr. Hanna', 'Cann, Mr. Ernest Charles',
           'Vander Planke, Miss. Augusta Maria',
           'Nicola-Yarred, Miss. Jamila',
           'Ahlin, Mrs. Johan (Johanna Persdotter Larsson)',
           'Turpin, Mrs. William John Robert (Dorothy Ann Wonnacott)',
           'Kraeff, Mr. Theodor', 'Laroche, Miss. Simonne Marie Anne Andree',
           'Devaney, Miss. Margaret Delia', 'Rogers, Mr. William John',
           'Lennon, Mr. Denis', "O'Driscoll, Miss. Bridget",
           'Samaan, Mr. Youssef',
           'Arnold-Franchi, Mrs. Josef (Josefine Franchi)',
           'Panula, Master. Juha Niilo', 'Nosworthy, Mr. Richard Cater',
           'Harper, Mrs. Henry Sleeper (Myna Haxtun)',
           'Faunthorpe, Mrs. Lizzie (Elizabeth Anne Wilkinson)',
           'Ostby, Mr. Engelhart Cornelius', 'Woolner, Mr. Hugh',
           'Rugg, Miss. Emily', 'Novel, Mr. Mansouer',
           'West, Miss. Constance Mirium',
           'Goodwin, Master. William Frederick', 'Sirayanian, Mr. Orsen',
           'Icard, Miss. Amelie', 'Harris, Mr. Henry Birkhardt',
           'Skoog, Master. Harald', 'Stewart, Mr. Albert A',
           'Moubarek, Master. Gerios', 'Nye, Mrs. (Elizabeth Ramell)',
           'Crease, Mr. Ernest James', 'Andersson, Miss. Erna Alexandra',
           'Kink, Mr. Vincenz', 'Jenkin, Mr. Stephen Curnow',
           'Goodwin, Miss. Lillian Amy', 'Hood, Mr. Ambrose Jr',
           'Chronopoulos, Mr. Apostolos', 'Bing, Mr. Lee',
           'Moen, Mr. Sigurd Hansen', 'Staneff, Mr. Ivan',
           'Moutal, Mr. Rahamin Haim', 'Caldwell, Master. Alden Gates',
           'Dowdell, Miss. Elizabeth', 'Waelens, Mr. Achille',
           'Sheerlinck, Mr. Jan Baptist', 'McDermott, Miss. Brigdet Delia',
           'Carrau, Mr. Francisco M', 'Ilett, Miss. Bertha',
           'Backstrom, Mrs. Karl Alfred (Maria Mathilda Gustafsson)',
           'Ford, Mr. William Neal', 'Slocovski, Mr. Selman Francis',
           'Fortune, Miss. Mabel Helen', 'Celotti, Mr. Francesco',
           'Christmann, Mr. Emil', 'Andreasson, Mr. Paul Edvin',
           'Chaffee, Mr. Herbert Fuller', 'Dean, Mr. Bertram Frank',
           'Coxon, Mr. Daniel', 'Shorney, Mr. Charles Joseph',
           'Goldschmidt, Mr. George B', 'Greenfield, Mr. William Bertram',
           'Doling, Mrs. John T (Ada Julia Bone)', 'Kantor, Mr. Sinai',
           'Petranec, Miss. Matilda', 'Petroff, Mr. Pastcho ("Pentcho")',
           'White, Mr. Richard Frasar', 'Johansson, Mr. Gustaf Joel',
           'Gustafsson, Mr. Anders Vilhelm', 'Mionoff, Mr. Stoytcho',
           'Salkjelsvik, Miss. Anna Kristine', 'Moss, Mr. Albert Johan',
           'Rekic, Mr. Tido', 'Moran, Miss. Bertha',
           'Porter, Mr. Walter Chamberlain', 'Zabour, Miss. Hileni',
           'Barton, Mr. David John', 'Jussila, Miss. Katriina',
           'Attalah, Miss. Malake', 'Pekoniemi, Mr. Edvard',
           'Connors, Mr. Patrick', 'Turpin, Mr. William John Robert',
           'Baxter, Mr. Quigg Edmond', 'Andersson, Miss. Ellis Anna Maria',
           'Hickman, Mr. Stanley George', 'Moore, Mr. Leonard Charles',
           'Nasser, Mr. Nicholas', 'Webber, Miss. Susan',
           'White, Mr. Percival Wayland', 'Nicola-Yarred, Master. Elias',
           'McMahon, Mr. Martin', 'Madsen, Mr. Fridtjof Arne',
           'Peter, Miss. Anna', 'Ekstrom, Mr. Johan', 'Drazenoic, Mr. Jozef',
           'Coelho, Mr. Domingos Fernandeo',
           'Robins, Mrs. Alexander A (Grace Charity Laury)',
           'Weisz, Mrs. Leopold (Mathilde Francoise Pede)',
           'Sobey, Mr. Samuel James Hayden', 'Richard, Mr. Emile',
           'Newsom, Miss. Helen Monypeny', 'Futrelle, Mr. Jacques Heath',
           'Osen, Mr. Olaf Elon', 'Giglio, Mr. Victor',
           'Boulos, Mrs. Joseph (Sultana)', 'Nysten, Miss. Anna Sofia',
           'Hakkarainen, Mrs. Pekka Pietari (Elin Matilda Dolck)',
           'Burke, Mr. Jeremiah', 'Andrew, Mr. Edgardo Samuel',
           'Nicholls, Mr. Joseph Charles',
           'Andersson, Mr. August Edvard ("Wennerstrom")',
           'Ford, Miss. Robina Maggie "Ruby"',
           'Navratil, Mr. Michel ("Louis M Hoffman")',
           'Byles, Rev. Thomas Roussel Davids', 'Bateman, Rev. Robert James',
           'Pears, Mrs. Thomas (Edith Wearne)', 'Meo, Mr. Alfonzo',
           'van Billiard, Mr. Austin Blyler', 'Olsen, Mr. Ole Martin',
           'Williams, Mr. Charles Duane', 'Gilnagh, Miss. Katherine "Katie"',
           'Corn, Mr. Harry', 'Smiljanic, Mr. Mile',
           'Sage, Master. Thomas Henry', 'Cribb, Mr. John Hatfield',
           'Watt, Mrs. James (Elizabeth "Bessie" Inglis Milne)',
           'Bengtsson, Mr. John Viktor', 'Calic, Mr. Jovo',
           'Panula, Master. Eino Viljami',
           'Goldsmith, Master. Frank John William "Frankie"',
           'Chibnall, Mrs. (Edith Martha Bowerman)',
           'Skoog, Mrs. William (Anna Bernhardina Karlsson)',
           'Baumann, Mr. John D', 'Ling, Mr. Lee',
           'Van der hoef, Mr. Wyckoff', 'Rice, Master. Arthur',
           'Johnson, Miss. Eleanor Ileen', 'Sivola, Mr. Antti Wilhelm',
           'Smith, Mr. James Clinch', 'Klasen, Mr. Klas Albin',
           'Lefebre, Master. Henry Forbes', 'Isham, Miss. Ann Elizabeth',
           'Hale, Mr. Reginald', 'Leonard, Mr. Lionel',
           'Sage, Miss. Constance Gladys', 'Pernot, Mr. Rene',
           'Asplund, Master. Clarence Gustaf Hugo',
           'Becker, Master. Richard F', 'Kink-Heilmann, Miss. Luise Gretchen',
           'Rood, Mr. Hugh Roscoe',
           'O\'Brien, Mrs. Thomas (Johanna "Hannah" Godfrey)',
           'Romaine, Mr. Charles Hallace ("Mr C Rolmane")',
           'Bourke, Mr. John', 'Turcin, Mr. Stjepan', 'Pinsky, Mrs. (Rosa)',
           'Carbines, Mr. William',
           'Andersen-Jensen, Miss. Carla Christine Nielsine',
           'Navratil, Master. Michel M',
           'Brown, Mrs. James Joseph (Margaret Tobin)',
           'Lurette, Miss. Elise', 'Mernagh, Mr. Robert',
           'Olsen, Mr. Karl Siegwart Andreas',
           'Madigan, Miss. Margaret "Maggie"',
           'Yrois, Miss. Henriette ("Mrs Harbeck")',
           'Vande Walle, Mr. Nestor Cyriel', 'Sage, Mr. Frederick',
           'Johanson, Mr. Jakob Alfred', 'Youseff, Mr. Gerious',
           'Cohen, Mr. Gurshon "Gus"', 'Strom, Miss. Telma Matilda',
           'Backstrom, Mr. Karl Alfred', 'Albimona, Mr. Nassef Cassem',
           'Carr, Miss. Helen "Ellen"', 'Blank, Mr. Henry', 'Ali, Mr. Ahmed',
           'Cameron, Miss. Clear Annie', 'Perkin, Mr. John Henry',
           'Givard, Mr. Hans Kristensen', 'Kiernan, Mr. Philip',
           'Newell, Miss. Madeleine', 'Honkanen, Miss. Eliina',
           'Jacobsohn, Mr. Sidney Samuel', 'Bazzani, Miss. Albina',
           'Harris, Mr. Walter', 'Sunderland, Mr. Victor Francis',
           'Bracken, Mr. James H', 'Green, Mr. George Henry',
           'Nenkoff, Mr. Christo', 'Hoyt, Mr. Frederick Maxfield',
           'Berglund, Mr. Karl Ivar Sven', 'Mellors, Mr. William John',
           'Lovell, Mr. John Hall ("Henry")', 'Fahlstrom, Mr. Arne Jonas',
           'Lefebre, Miss. Mathilde',
           'Harris, Mrs. Henry Birkhardt (Irene Wallach)',
           'Larsson, Mr. Bengt Edvin', 'Sjostedt, Mr. Ernst Adolf',
           'Asplund, Miss. Lillian Gertrud',
           'Leyson, Mr. Robert William Norman',
           'Harknett, Miss. Alice Phoebe', 'Hold, Mr. Stephen',
           'Collyer, Miss. Marjorie "Lottie"',
           'Pengelly, Mr. Frederick William', 'Hunt, Mr. George Henry',
           'Zabour, Miss. Thamine', 'Murphy, Miss. Katherine "Kate"',
           'Coleridge, Mr. Reginald Charles', 'Maenpaa, Mr. Matti Alexanteri',
           'Attalah, Mr. Sleiman', 'Minahan, Dr. William Edward',
           'Lindahl, Miss. Agda Thorilda Viktoria',
           'Hamalainen, Mrs. William (Anna)', 'Beckwith, Mr. Richard Leonard',
           'Carter, Rev. Ernest Courtenay', 'Reed, Mr. James George',
           'Strom, Mrs. Wilhelm (Elna Matilda Persson)',
           'Stead, Mr. William Thomas', 'Lobb, Mr. William Arthur',
           'Rosblom, Mrs. Viktor (Helena Wilhelmina)',
           'Touma, Mrs. Darwis (Hanne Youssef Razi)',
           'Thorne, Mrs. Gertrude Maybelle', 'Cherry, Miss. Gladys',
           'Ward, Miss. Anna', 'Parrish, Mrs. (Lutie Davis)',
           'Smith, Mr. Thomas', 'Asplund, Master. Edvin Rojj Felix',
           'Taussig, Mr. Emil', 'Harrison, Mr. William', 'Henry, Miss. Delia',
           'Reeves, Mr. David', 'Panula, Mr. Ernesti Arvid',
           'Persson, Mr. Ernst Ulrik',
           'Graham, Mrs. William Thompson (Edith Junkins)',
           'Bissette, Miss. Amelia', 'Cairns, Mr. Alexander',
           'Tornquist, Mr. William Henry',
           'Mellinger, Mrs. (Elizabeth Anne Maidment)',
           'Natsch, Mr. Charles H', 'Healy, Miss. Hanora "Nora"',
           'Andrews, Miss. Kornelia Theodosia',
           'Lindblom, Miss. Augusta Charlotta', 'Parkes, Mr. Francis "Frank"',
           'Rice, Master. Eric', 'Abbott, Mrs. Stanton (Rosa Hunt)',
           'Duane, Mr. Frank', 'Olsson, Mr. Nils Johan Goransson',
           'de Pelsmaeker, Mr. Alfons', 'Dorking, Mr. Edward Arthur',
           'Smith, Mr. Richard William', 'Stankovic, Mr. Ivan',
           'de Mulder, Mr. Theodore', 'Naidenoff, Mr. Penko',
           'Hosono, Mr. Masabumi', 'Connolly, Miss. Kate',
           'Barber, Miss. Ellen "Nellie"',
           'Bishop, Mrs. Dickinson H (Helen Walton)',
           'Levy, Mr. Rene Jacques', 'Haas, Miss. Aloisia',
           'Mineff, Mr. Ivan', 'Lewy, Mr. Ervin G', 'Hanna, Mr. Mansour',
           'Allison, Miss. Helen Loraine', 'Saalfeld, Mr. Adolphe',
           'Baxter, Mrs. James (Helene DeLaudeniere Chaput)',
           'Kelly, Miss. Anna Katherine "Annie Kate"', 'McCoy, Mr. Bernard',
           'Johnson, Mr. William Cahoone Jr', 'Keane, Miss. Nora A',
           'Williams, Mr. Howard Hugh "Harry"',
           'Allison, Master. Hudson Trevor', 'Fleming, Miss. Margaret',
           'Penasco y Castellana, Mrs. Victor de Satode (Maria Josefa Perez de Soto y Vallejo)',
           'Abelson, Mr. Samuel', 'Francatelli, Miss. Laura Mabel',
           'Hays, Miss. Margaret Bechstein', 'Ryerson, Miss. Emily Borie',
           'Lahtinen, Mrs. William (Anna Sylfven)', 'Hendekovic, Mr. Ignjac',
           'Hart, Mr. Benjamin', 'Nilsson, Miss. Helmina Josefina',
           'Kantor, Mrs. Sinai (Miriam Sternin)', 'Moraweck, Dr. Ernest',
           'Wick, Miss. Mary Natalie',
           'Spedden, Mrs. Frederic Oakley (Margaretta Corning Stone)',
           'Dennis, Mr. Samuel', 'Danoff, Mr. Yoto',
           'Slayter, Miss. Hilda Mary',
           'Caldwell, Mrs. Albert Francis (Sylvia Mae Harbaugh)',
           'Sage, Mr. George John Jr', 'Young, Miss. Marie Grice',
           'Nysveen, Mr. Johan Hansen', 'Ball, Mrs. (Ada E Hall)',
           'Goldsmith, Mrs. Frank John (Emily Alice Brown)',
           'Hippach, Miss. Jean Gertrude', 'McCoy, Miss. Agnes',
           'Partner, Mr. Austen', 'Graham, Mr. George Edward',
           'Vander Planke, Mr. Leo Edmondus',
           'Frauenthal, Mrs. Henry William (Clara Heinsheimer)',
           'Denkoff, Mr. Mitto', 'Pears, Mr. Thomas Clinton',
           'Burns, Miss. Elizabeth Margaret', 'Dahl, Mr. Karl Edwart',
           'Blackwell, Mr. Stephen Weart', 'Navratil, Master. Edmond Roger',
           'Fortune, Miss. Alice Elizabeth', 'Collander, Mr. Erik Gustaf',
           'Sedgwick, Mr. Charles Frederick Waddington',
           'Fox, Mr. Stanley Hubert', 'Brown, Miss. Amelia "Mildred"',
           'Smith, Miss. Marion Elsie',
           'Davison, Mrs. Thomas Henry (Mary E Finck)',
           'Coutts, Master. William Loch "William"', 'Dimic, Mr. Jovan',
           'Odahl, Mr. Nils Martin', 'Williams-Lambert, Mr. Fletcher Fellows',
           'Elias, Mr. Tannous', 'Arnold-Franchi, Mr. Josef',
           'Yousif, Mr. Wazli', 'Vanden Steen, Mr. Leo Peter',
           'Bowerman, Miss. Elsie Edith', 'Funk, Miss. Annie Clemmer',
           'McGovern, Miss. Mary', 'Mockler, Miss. Helen Mary "Ellie"',
           'Skoog, Mr. Wilhelm', 'del Carlo, Mr. Sebastiano',
           'Barbara, Mrs. (Catherine David)', 'Asim, Mr. Adola',
           "O'Brien, Mr. Thomas", 'Adahl, Mr. Mauritz Nils Martin',
           'Warren, Mrs. Frank Manley (Anna Sophia Atkinson)',
           'Moussa, Mrs. (Mantoura Boulos)', 'Jermyn, Miss. Annie',
           'Aubart, Mme. Leontine Pauline', 'Harder, Mr. George Achilles',
           'Wiklund, Mr. Jakob Alfred', 'Beavan, Mr. William Thomas',
           'Ringhini, Mr. Sante', 'Palsson, Miss. Stina Viola',
           'Meyer, Mrs. Edgar Joseph (Leila Saks)',
           'Landergren, Miss. Aurora Adelia', 'Widener, Mr. Harry Elkins',
           'Betros, Mr. Tannous', 'Gustafsson, Mr. Karl Gideon',
           'Bidois, Miss. Rosalie', 'Nakid, Miss. Maria ("Mary")',
           'Tikkanen, Mr. Juho',
           'Holverson, Mrs. Alexander Oskar (Mary Aline Towner)',
           'Plotcharsky, Mr. Vasil', 'Davies, Mr. Charles Henry',
           'Goodwin, Master. Sidney Leonard', 'Buss, Miss. Kate',
           'Sadlier, Mr. Matthew', 'Lehmann, Miss. Bertha',
           'Carter, Mr. William Ernest', 'Jansson, Mr. Carl Olof',
           'Gustafsson, Mr. Johan Birger', 'Newell, Miss. Marjorie',
           'Sandstrom, Mrs. Hjalmar (Agnes Charlotta Bengtsson)',
           'Johansson, Mr. Erik', 'Olsson, Miss. Elina',
           'McKane, Mr. Peter David', 'Pain, Dr. Alfred',
           'Trout, Mrs. William H (Jessie L)', 'Niskanen, Mr. Juha',
           'Adams, Mr. John', 'Jussila, Miss. Mari Aina',
           'Hakkarainen, Mr. Pekka Pietari', 'Oreskovic, Miss. Marija',
           'Gale, Mr. Shadrach', 'Widegren, Mr. Carl/Charles Peter',
           'Richards, Master. William Rowe',
           'Birkeland, Mr. Hans Martin Monsen', 'Lefebre, Miss. Ida',
           'Sdycoff, Mr. Todor', 'Hart, Mr. Henry', 'Minahan, Miss. Daisy E',
           'Cunningham, Mr. Alfred Fleming', 'Sundman, Mr. Johan Julian',
           'Meek, Mrs. Thomas (Annie Louise Rowley)',
           'Drew, Mrs. James Vivian (Lulu Thorne Christian)',
           'Silven, Miss. Lyyli Karoliina', 'Matthews, Mr. William John',
           'Van Impe, Miss. Catharina', 'Gheorgheff, Mr. Stanio',
           'Charters, Mr. David', 'Zimmerman, Mr. Leo',
           'Danbom, Mrs. Ernst Gilbert (Anna Sigrid Maria Brogren)',
           'Rosblom, Mr. Viktor Richard', 'Wiseman, Mr. Phillippe',
           'Clarke, Mrs. Charles V (Ada Maria Winfield)',
           'Phillips, Miss. Kate Florence ("Mrs Kate Louise Phillips Marshall")',
           'Flynn, Mr. James', 'Pickard, Mr. Berk (Berk Trembisky)',
           'Bjornstrom-Steffansson, Mr. Mauritz Hakan',
           'Thorneycroft, Mrs. Percival (Florence Kate White)',
           'Louch, Mrs. Charles Alexander (Alice Adelaide Slow)',
           'Kallio, Mr. Nikolai Erland', 'Silvey, Mr. William Baird',
           'Carter, Miss. Lucile Polk',
           'Ford, Miss. Doolina Margaret "Daisy"',
           'Richards, Mrs. Sidney (Emily Hocking)', 'Fortune, Mr. Mark',
           'Kvillner, Mr. Johan Henrik Johannesson',
           'Hart, Mrs. Benjamin (Esther Ada Bloomfield)', 'Hampe, Mr. Leon',
           'Petterson, Mr. Johan Emil', 'Reynaldo, Ms. Encarnacion',
           'Johannesen-Bratthammer, Mr. Bernt', 'Dodge, Master. Washington',
           'Mellinger, Miss. Madeleine Violet', 'Seward, Mr. Frederic Kimber',
           'Baclini, Miss. Marie Catherine', 'Peuchen, Major. Arthur Godfrey',
           'West, Mr. Edwy Arthur', 'Hagland, Mr. Ingvald Olai Olsen',
           'Foreman, Mr. Benjamin Laventall', 'Goldenberg, Mr. Samuel L',
           'Peduzzi, Mr. Joseph', 'Jalsevac, Mr. Ivan',
           'Millet, Mr. Francis Davis', 'Kenyon, Mrs. Frederick R (Marion)',
           'Toomey, Miss. Ellen', "O'Connor, Mr. Maurice",
           'Anderson, Mr. Harry', 'Morley, Mr. William', 'Gee, Mr. Arthur H',
           'Milling, Mr. Jacob Christian', 'Maisner, Mr. Simon',
           'Goncalves, Mr. Manuel Estanslas', 'Campbell, Mr. William',
           'Smart, Mr. John Montgomery', 'Scanlan, Mr. James',
           'Baclini, Miss. Helene Barbara', 'Keefe, Mr. Arthur',
           'Cacic, Mr. Luka', 'West, Mrs. Edwy Arthur (Ada Mary Worth)',
           'Jerwan, Mrs. Amin S (Marie Marthe Thuillard)',
           'Strandberg, Miss. Ida Sofia', 'Clifford, Mr. George Quincy',
           'Renouf, Mr. Peter Henry', 'Braund, Mr. Lewis Richard',
           'Karlsson, Mr. Nils August', 'Hirvonen, Miss. Hildur E',
           'Goodwin, Master. Harold Victor',
           'Frost, Mr. Anthony Wood "Archie"', 'Rouse, Mr. Richard Henry',
           'Turkula, Mrs. (Hedwig)', 'Bishop, Mr. Dickinson H',
           'Lefebre, Miss. Jeannie',
           'Hoyt, Mrs. Frederick Maxfield (Jane Anne Forby)',
           'Kent, Mr. Edward Austin', 'Somerton, Mr. Francis William',
           'Coutts, Master. Eden Leslie "Neville"',
           'Hagland, Mr. Konrad Mathias Reiersen', 'Windelov, Mr. Einar',
           'Molson, Mr. Harry Markland', 'Artagaveytia, Mr. Ramon',
           'Stanley, Mr. Edward Roland', 'Yousseff, Mr. Gerious',
           'Eustis, Miss. Elizabeth Mussey',
           'Shellard, Mr. Frederick William',
           'Allison, Mrs. Hudson J C (Bessie Waldo Daniels)',
           'Svensson, Mr. Olof', 'Calic, Mr. Petar', 'Canavan, Miss. Mary',
           "O'Sullivan, Miss. Bridget Mary", 'Laitinen, Miss. Kristina Sofia',
           'Maioni, Miss. Roberta',
           'Penasco y Castellana, Mr. Victor de Satode',
           'Quick, Mrs. Frederick Charles (Jane Richards)',
           'Bradley, Mr. George ("George Arthur Brayton")',
           'Olsen, Mr. Henry Margido', 'Lang, Mr. Fang',
           'Daly, Mr. Eugene Patrick', 'Webber, Mr. James',
           'McGough, Mr. James Robert',
           'Rothschild, Mrs. Martin (Elizabeth L. Barrett)',
           'Coleff, Mr. Satio', 'Walker, Mr. William Anderson',
           'Lemore, Mrs. (Amelia Milley)', 'Ryan, Mr. Patrick',
           'Angle, Mrs. William A (Florence "Mary" Agnes Hughes)',
           'Pavlovic, Mr. Stefo', 'Perreault, Miss. Anne', 'Vovk, Mr. Janko',
           'Lahoud, Mr. Sarkis',
           'Hippach, Mrs. Louis Albert (Ida Sophia Fischer)',
           'Kassem, Mr. Fared', 'Farrell, Mr. James', 'Ridsdale, Miss. Lucy',
           'Farthing, Mr. John', 'Salonen, Mr. Johan Werner',
           'Hocking, Mr. Richard George', 'Quick, Miss. Phyllis May',
           'Toufik, Mr. Nakli', 'Elias, Mr. Joseph Jr',
           'Peter, Mrs. Catherine (Catherine Rizk)', 'Cacic, Miss. Marija',
           'Hart, Miss. Eva Miriam', 'Butt, Major. Archibald Willingham',
           'LeRoy, Miss. Bertha', 'Risien, Mr. Samuel Beard',
           'Frolicher, Miss. Hedwig Margaritha', 'Crosby, Miss. Harriet R',
           'Andersson, Miss. Ingeborg Constanzia',
           'Andersson, Miss. Sigrid Elisabeth', 'Beane, Mr. Edward',
           'Douglas, Mr. Walter Donald', 'Nicholson, Mr. Arthur Ernest',
           'Beane, Mrs. Edward (Ethel Clarke)', 'Padro y Manent, Mr. Julian',
           'Goldsmith, Mr. Frank John', 'Davies, Master. John Morgan Jr',
           'Thayer, Mr. John Borland Jr', 'Sharp, Mr. Percival James R',
           "O'Brien, Mr. Timothy", 'Leeni, Mr. Fahim ("Philip Zenni")',
           'Ohman, Miss. Velin', 'Wright, Mr. George',
           'Duff Gordon, Lady. (Lucille Christiana Sutherland) ("Mrs Morgan")',
           'Robbins, Mr. Victor', 'Taussig, Mrs. Emil (Tillie Mandelbaum)',
           'de Messemaeker, Mrs. Guillaume Joseph (Emma)',
           'Morrow, Mr. Thomas Rowan', 'Sivic, Mr. Husein',
           'Norman, Mr. Robert Douglas', 'Simmons, Mr. John',
           'Meanwell, Miss. (Marion Ogden)', 'Davies, Mr. Alfred J',
           'Stoytcheff, Mr. Ilia',
           'Palsson, Mrs. Nils (Alma Cornelia Berglund)',
           'Doharr, Mr. Tannous', 'Jonsson, Mr. Carl', 'Harris, Mr. George',
           'Appleton, Mrs. Edward Dale (Charlotte Lamson)',
           'Flynn, Mr. John Irwin ("Irving")', 'Kelly, Miss. Mary',
           'Rush, Mr. Alfred George John', 'Patchett, Mr. George',
           'Garside, Miss. Ethel',
           'Silvey, Mrs. William Baird (Alice Munger)',
           'Caram, Mrs. Joseph (Maria Elias)', 'Jussila, Mr. Eiriik',
           'Christy, Miss. Julie Rachel',
           'Thayer, Mrs. John Borland (Marian Longstreth Morris)',
           'Downton, Mr. William James', 'Ross, Mr. John Hugo',
           'Paulner, Mr. Uscher', 'Taussig, Miss. Ruth',
           'Jarvis, Mr. John Denzil', 'Frolicher-Stehli, Mr. Maxmillian',
           'Gilinski, Mr. Eliezer', 'Murdlin, Mr. Joseph',
           'Rintamaki, Mr. Matti',
           'Stephenson, Mrs. Walter Bertram (Martha Eustis)',
           'Elsbury, Mr. William James', 'Bourke, Miss. Mary',
           'Chapman, Mr. John Henry', 'Van Impe, Mr. Jean Baptiste',
           'Leitch, Miss. Jessie Wills', 'Johnson, Mr. Alfred',
           'Boulos, Mr. Hanna',
           'Duff Gordon, Sir. Cosmo Edmund ("Mr Morgan")',
           'Jacobsohn, Mrs. Sidney Samuel (Amy Frances Christy)',
           'Slabenoff, Mr. Petco', 'Harrington, Mr. Charles H',
           'Torber, Mr. Ernst William', 'Homer, Mr. Harry ("Mr E Haven")',
           'Lindell, Mr. Edvard Bengtsson', 'Karaic, Mr. Milan',
           'Daniel, Mr. Robert Williams',
           'Laroche, Mrs. Joseph (Juliette Marie Louise Lafargue)',
           'Shutes, Miss. Elizabeth W',
           'Andersson, Mrs. Anders Johan (Alfrida Konstantia Brogren)',
           'Jardin, Mr. Jose Neto', 'Murphy, Miss. Margaret Jane',
           'Horgan, Mr. John', 'Brocklebank, Mr. William Alfred',
           'Herman, Miss. Alice', 'Danbom, Mr. Ernst Gilbert',
           'Lobb, Mrs. William Arthur (Cordelia K Stanlick)',
           'Becker, Miss. Marion Louise', 'Gavey, Mr. Lawrence',
           'Yasbeck, Mr. Antoni', 'Kimball, Mr. Edwin Nelson Jr',
           'Nakid, Mr. Sahid', 'Hansen, Mr. Henry Damsgaard',
           'Bowen, Mr. David John "Dai"', 'Sutton, Mr. Frederick',
           'Kirkland, Rev. Charles Leonard', 'Longley, Miss. Gretchen Fiske',
           'Bostandyeff, Mr. Guentcho', "O'Connell, Mr. Patrick D",
           'Barkworth, Mr. Algernon Henry Wilson',
           'Lundahl, Mr. Johan Svensson', 'Stahelin-Maeglin, Dr. Max',
           'Parr, Mr. William Henry Marsh', 'Skoog, Miss. Mabel',
           'Davis, Miss. Mary', 'Leinonen, Mr. Antti Gustaf',
           'Collyer, Mr. Harvey', 'Panula, Mrs. Juha (Maria Emilia Ojala)',
           'Thorneycroft, Mr. Percival', 'Jensen, Mr. Hans Peder',
           'Sagesser, Mlle. Emma', 'Skoog, Miss. Margit Elizabeth',
           'Foo, Mr. Choong', 'Baclini, Miss. Eugenie',
           'Harper, Mr. Henry Sleeper', 'Cor, Mr. Liudevit',
           'Simonius-Blumer, Col. Oberst Alfons', 'Willey, Mr. Edward',
           'Stanley, Miss. Amy Zillah Elsie', 'Mitkoff, Mr. Mito',
           'Doling, Miss. Elsie', 'Kalvik, Mr. Johannes Halvorsen',
           'O\'Leary, Miss. Hanora "Norah"', 'Hegarty, Miss. Hanora "Nora"',
           'Hickman, Mr. Leonard Mark', 'Radeff, Mr. Alexander',
           'Bourke, Mrs. John (Catherine)', 'Eitemiller, Mr. George Floyd',
           'Newell, Mr. Arthur Webster', 'Frauenthal, Dr. Henry William',
           'Badt, Mr. Mohamed', 'Colley, Mr. Edward Pomeroy',
           'Coleff, Mr. Peju', 'Lindqvist, Mr. Eino William',
           'Hickman, Mr. Lewis', 'Butler, Mr. Reginald Fenton',
           'Rommetvedt, Mr. Knud Paust', 'Cook, Mr. Jacob',
           'Taylor, Mrs. Elmer Zebley (Juliet Cummins Wright)',
           'Brown, Mrs. Thomas William Solomon (Elizabeth Catherine Ford)',
           'Davidson, Mr. Thornton', 'Mitchell, Mr. Henry Michael',
           'Wilhelms, Mr. Charles', 'Watson, Mr. Ennis Hastings',
           'Edvardsson, Mr. Gustaf Hjalmar', 'Sawyer, Mr. Frederick Charles',
           'Turja, Miss. Anna Sofia',
           'Goodwin, Mrs. Frederick (Augusta Tyler)',
           'Cardeza, Mr. Thomas Drake Martinez', 'Peters, Miss. Katie',
           'Hassab, Mr. Hammad', 'Olsvigen, Mr. Thor Anderson',
           'Goodwin, Mr. Charles Edward', 'Brown, Mr. Thomas William Solomon',
           'Laroche, Mr. Joseph Philippe Lemercier',
           'Panula, Mr. Jaako Arnold', 'Dakic, Mr. Branko',
           'Fischer, Mr. Eberhard Thelander',
           'Madill, Miss. Georgette Alexandra', 'Dick, Mr. Albert Adrian',
           'Karun, Miss. Manca', 'Lam, Mr. Ali', 'Saad, Mr. Khalil',
           'Weir, Col. John', 'Chapman, Mr. Charles Henry',
           'Kelly, Mr. James', 'Mullens, Miss. Katherine "Katie"',
           'Thayer, Mr. John Borland',
           'Humblen, Mr. Adolf Mathias Nicolai Olsen',
           'Astor, Mrs. John Jacob (Madeleine Talmadge Force)',
           'Silverthorne, Mr. Spencer Victor', 'Barbara, Miss. Saiide',
           'Gallagher, Mr. Martin', 'Hansen, Mr. Henrik Juul',
           'Morley, Mr. Henry Samuel ("Mr Henry Marshall")',
           'Kelly, Mrs. Florence "Fannie"',
           'Calderhead, Mr. Edward Pennington', 'Cleaver, Miss. Alice',
           'Moubarek, Master. Halim Gonios ("William George")',
           'Mayne, Mlle. Berthe Antonine ("Mrs de Villiers")',
           'Klaber, Mr. Herman', 'Taylor, Mr. Elmer Zebley',
           'Larsson, Mr. August Viktor', 'Greenberg, Mr. Samuel',
           'Soholt, Mr. Peter Andreas Lauritz Andersen',
           'Endres, Miss. Caroline Louise',
           'Troutt, Miss. Edwina Celia "Winnie"', 'McEvoy, Mr. Michael',
           'Johnson, Mr. Malkolm Joackim',
           'Harper, Miss. Annie Jessie "Nina"', 'Jensen, Mr. Svend Lauritz',
           'Gillespie, Mr. William Henry', 'Hodges, Mr. Henry Price',
           'Chambers, Mr. Norman Campbell', 'Oreskovic, Mr. Luka',
           'Renouf, Mrs. Peter Henry (Lillian Jefferys)',
           'Mannion, Miss. Margareth', 'Bryhl, Mr. Kurt Arnold Gottfrid',
           'Ilmakangas, Miss. Pieta Sofia', 'Allen, Miss. Elisabeth Walton',
           'Hassan, Mr. Houssein G N', 'Knight, Mr. Robert J',
           'Berriman, Mr. William John', 'Troupiansky, Mr. Moses Aaron',
           'Williams, Mr. Leslie', 'Ford, Mrs. Edward (Margaret Ann Watson)',
           'Lesurer, Mr. Gustave J', 'Ivanoff, Mr. Kanio',
           'Nankoff, Mr. Minko', 'Hawksford, Mr. Walter James',
           'Cavendish, Mr. Tyrell William',
           'Ryerson, Miss. Susan Parker "Suzette"', 'McNamee, Mr. Neal',
           'Stranden, Mr. Juho', 'Crosby, Capt. Edward Gifford',
           'Abbott, Mr. Rossmore Edward', 'Sinkkonen, Miss. Anna',
           'Marvin, Mr. Daniel Warner', 'Connaghton, Mr. Michael',
           'Wells, Miss. Joan', 'Moor, Master. Meier',
           'Vande Velde, Mr. Johannes Joseph', 'Jonkoff, Mr. Lalio',
           'Herman, Mrs. Samuel (Jane Laver)', 'Hamalainen, Master. Viljo',
           'Carlsson, Mr. August Sigfrid', 'Bailey, Mr. Percy Andrew',
           'Theobald, Mr. Thomas Leonard',
           'Rothes, the Countess. of (Lucy Noel Martha Dyer-Edwards)',
           'Garfirth, Mr. John', 'Nirva, Mr. Iisakki Antino Aijo',
           'Barah, Mr. Hanna Assi',
           'Carter, Mrs. William Ernest (Lucile Polk)',
           'Eklund, Mr. Hans Linus', 'Hogeboom, Mrs. John C (Anna Andrews)',
           'Brewe, Dr. Arthur Jackson', 'Mangan, Miss. Mary',
           'Moran, Mr. Daniel J', 'Gronnestad, Mr. Daniel Danielsen',
           'Lievens, Mr. Rene Aime', 'Jensen, Mr. Niels Peder',
           'Mack, Mrs. (Mary)', 'Elias, Mr. Dibo',
           'Hocking, Mrs. Elizabeth (Eliza Needs)',
           'Myhrman, Mr. Pehr Fabian Oliver Malkolm', 'Tobin, Mr. Roger',
           'Emanuel, Miss. Virginia Ethel', 'Kilgannon, Mr. Thomas J',
           'Robert, Mrs. Edward Scott (Elisabeth Walton McMillan)',
           'Ayoub, Miss. Banoura',
           'Dick, Mrs. Albert Adrian (Vera Gillespie)',
           'Long, Mr. Milton Clyde', 'Johnston, Mr. Andrew G',
           'Ali, Mr. William', 'Harmer, Mr. Abraham (David Lishin)',
           'Sjoblom, Miss. Anna Sofia', 'Rice, Master. George Hugh',
           'Dean, Master. Bertram Vere', 'Guggenheim, Mr. Benjamin',
           'Keane, Mr. Andrew "Andy"', 'Gaskell, Mr. Alfred',
           'Sage, Miss. Stella Anna', 'Hoyt, Mr. William Fisher',
           'Dantcheff, Mr. Ristiu', 'Otter, Mr. Richard',
           'Leader, Dr. Alice (Farnham)', 'Osman, Mrs. Mara',
           'Ibrahim Shawah, Mr. Yousseff',
           'Van Impe, Mrs. Jean Baptiste (Rosalie Paula Govaert)',
           'Ponesell, Mr. Martin',
           'Collyer, Mrs. Harvey (Charlotte Annie Tate)',
           'Carter, Master. William Thornton II',
           'Thomas, Master. Assad Alexander', 'Hedman, Mr. Oskar Arvid',
           'Johansson, Mr. Karl Johan', 'Andrews, Mr. Thomas Jr',
           'Pettersson, Miss. Ellen Natalia', 'Meyer, Mr. August',
           'Chambers, Mrs. Norman Campbell (Bertha Griggs)',
           'Alexander, Mr. William', 'Lester, Mr. James',
           'Slemen, Mr. Richard James', 'Andersson, Miss. Ebba Iris Alfrida',
           'Tomlin, Mr. Ernest Portage', 'Fry, Mr. Richard',
           'Heininen, Miss. Wendla Maria', 'Mallet, Mr. Albert',
           'Holm, Mr. John Fredrik Alexander', 'Skoog, Master. Karl Thorsten',
           'Hays, Mrs. Charles Melville (Clara Jennings Gregg)',
           'Lulic, Mr. Nikola', 'Reuchlin, Jonkheer. John George',
           'Moor, Mrs. (Beila)', 'Panula, Master. Urho Abraham',
           'Flynn, Mr. John', 'Lam, Mr. Len', 'Mallet, Master. Andre',
           'McCormack, Mr. Thomas Joseph',
           'Stone, Mrs. George Nelson (Martha Evelyn)',
           'Yasbeck, Mrs. Antoni (Selini Alexander)',
           'Richards, Master. George Sibley', 'Saad, Mr. Amin',
           'Augustsson, Mr. Albert', 'Allum, Mr. Owen George',
           'Compton, Miss. Sara Rebecca', 'Pasic, Mr. Jakob',
           'Sirota, Mr. Maurice', 'Chip, Mr. Chang', 'Marechal, Mr. Pierre',
           'Alhomaki, Mr. Ilmari Rudolf', 'Mudd, Mr. Thomas Charles',
           'Serepeca, Miss. Augusta', 'Lemberopolous, Mr. Peter L',
           'Culumovic, Mr. Jeso', 'Abbing, Mr. Anthony',
           'Sage, Mr. Douglas Bullen', 'Markoff, Mr. Marin',
           'Harper, Rev. John',
           'Goldenberg, Mrs. Samuel L (Edwiga Grabowska)',
           'Andersson, Master. Sigvard Harald Elias', 'Svensson, Mr. Johan',
           'Boulos, Miss. Nourelain', 'Lines, Miss. Mary Conover',
           'Carter, Mrs. Ernest Courtenay (Lilian Hughes)',
           'Aks, Mrs. Sam (Leah Rosen)',
           'Wick, Mrs. George Dennick (Mary Hitchcock)',
           'Daly, Mr. Peter Denis ', 'Baclini, Mrs. Solomon (Latifa Qurban)',
           'Razi, Mr. Raihed', 'Hansen, Mr. Claus Peter',
           'Giles, Mr. Frederick Edward',
           'Swift, Mrs. Frederick Joel (Margaret Welles Barron)',
           'Sage, Miss. Dorothy Edith "Dolly"', 'Gill, Mr. John William',
           'Bystrom, Mrs. (Karolina)', 'Duran y More, Miss. Asuncion',
           'Roebling, Mr. Washington Augustus II',
           'van Melkebeke, Mr. Philemon', 'Johnson, Master. Harold Theodor',
           'Balkic, Mr. Cerin',
           'Beckwith, Mrs. Richard Leonard (Sallie Monypeny)',
           'Carlsson, Mr. Frans Olof', 'Vander Cruyssen, Mr. Victor',
           'Abelson, Mrs. Samuel (Hannah Wizosky)',
           'Najib, Miss. Adele Kiamie "Jane"',
           'Gustafsson, Mr. Alfred Ossian', 'Petroff, Mr. Nedelio',
           'Laleff, Mr. Kristo',
           'Potter, Mrs. Thomas Jr (Lily Alexenia Wilson)',
           'Shelley, Mrs. William (Imanita Parrish Hall)',
           'Markun, Mr. Johann', 'Dahlberg, Miss. Gerda Ulrika',
           'Banfield, Mr. Frederick James', 'Sutehall, Mr. Henry Jr',
           'Rice, Mrs. William (Margaret Norton)', 'Montvila, Rev. Juozas',
           'Graham, Miss. Margaret Edith',
           'Johnston, Miss. Catherine Helen "Carrie"',
           'Behr, Mr. Karl Howell', 'Dooley, Mr. Patrick'], dtype=object)




```python
df1["salutation"]=df1["Name"].str.split(",", expand=True)[1].str.split(".",expand=True)[0]
```


```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
      <th>Embarked</th>
      <th>cabin_name</th>
      <th>salutation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>7.2500</td>
      <td>S</td>
      <td>B</td>
      <td>Mr</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>71.2833</td>
      <td>C</td>
      <td>C</td>
      <td>Mrs</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>7.9250</td>
      <td>S</td>
      <td>B</td>
      <td>Miss</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>53.1000</td>
      <td>S</td>
      <td>C</td>
      <td>Mrs</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>8.0500</td>
      <td>S</td>
      <td>B</td>
      <td>Mr</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>886</th>
      <td>0</td>
      <td>2</td>
      <td>Montvila, Rev. Juozas</td>
      <td>male</td>
      <td>27.0</td>
      <td>0</td>
      <td>0</td>
      <td>13.0000</td>
      <td>S</td>
      <td>B</td>
      <td>Rev</td>
    </tr>
    <tr>
      <th>887</th>
      <td>1</td>
      <td>1</td>
      <td>Graham, Miss. Margaret Edith</td>
      <td>female</td>
      <td>19.0</td>
      <td>0</td>
      <td>0</td>
      <td>30.0000</td>
      <td>S</td>
      <td>B</td>
      <td>Miss</td>
    </tr>
    <tr>
      <th>888</th>
      <td>0</td>
      <td>3</td>
      <td>Johnston, Miss. Catherine Helen "Carrie"</td>
      <td>female</td>
      <td>28.0</td>
      <td>1</td>
      <td>2</td>
      <td>23.4500</td>
      <td>S</td>
      <td>B</td>
      <td>Miss</td>
    </tr>
    <tr>
      <th>889</th>
      <td>1</td>
      <td>1</td>
      <td>Behr, Mr. Karl Howell</td>
      <td>male</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>30.0000</td>
      <td>C</td>
      <td>C</td>
      <td>Mr</td>
    </tr>
    <tr>
      <th>890</th>
      <td>0</td>
      <td>3</td>
      <td>Dooley, Mr. Patrick</td>
      <td>male</td>
      <td>32.0</td>
      <td>0</td>
      <td>0</td>
      <td>7.7500</td>
      <td>Q</td>
      <td>B</td>
      <td>Mr</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 11 columns</p>
</div>




```python
sns.countplot(df1["salutation"]);
```

    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    


    
![png](output_53_1.png)
    



```python
numeric=["float","int"]
df1.select_dtypes(include=numeric).columns
```




    Index(['Age', 'SibSp', 'Parch', 'Fare'], dtype='object')




```python
df1["family_member"]=df1["Parch"]+df1["SibSp"]
```


```python
sns.countplot(df1["family_member"]);
```

    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    


    
![png](output_56_1.png)
    



```python
df1["Age"].agg(["max","min","mean"])
```




    max     80.000000
    min      0.420000
    mean    29.361582
    Name: Age, dtype: float64




```python
plt.hist(df1["Age"]);
```


    
![png](output_58_0.png)
    



```python
sns.distplot(df1["Age"]);
```

    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\distributions.py:2619: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    


    
![png](output_59_1.png)
    



```python
import numpy as np
df1["Age_category"]=pd.cut(df1.Age,[0,14,25,60,np.inf],labels=["children","youth","adults","older"])
```


```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
      <th>Embarked</th>
      <th>cabin_name</th>
      <th>salutation</th>
      <th>family_member</th>
      <th>Age_category</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>7.2500</td>
      <td>S</td>
      <td>B</td>
      <td>Mr</td>
      <td>1</td>
      <td>youth</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>71.2833</td>
      <td>C</td>
      <td>C</td>
      <td>Mrs</td>
      <td>1</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>7.9250</td>
      <td>S</td>
      <td>B</td>
      <td>Miss</td>
      <td>0</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>53.1000</td>
      <td>S</td>
      <td>C</td>
      <td>Mrs</td>
      <td>1</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>8.0500</td>
      <td>S</td>
      <td>B</td>
      <td>Mr</td>
      <td>0</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>886</th>
      <td>0</td>
      <td>2</td>
      <td>Montvila, Rev. Juozas</td>
      <td>male</td>
      <td>27.0</td>
      <td>0</td>
      <td>0</td>
      <td>13.0000</td>
      <td>S</td>
      <td>B</td>
      <td>Rev</td>
      <td>0</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>887</th>
      <td>1</td>
      <td>1</td>
      <td>Graham, Miss. Margaret Edith</td>
      <td>female</td>
      <td>19.0</td>
      <td>0</td>
      <td>0</td>
      <td>30.0000</td>
      <td>S</td>
      <td>B</td>
      <td>Miss</td>
      <td>0</td>
      <td>youth</td>
    </tr>
    <tr>
      <th>888</th>
      <td>0</td>
      <td>3</td>
      <td>Johnston, Miss. Catherine Helen "Carrie"</td>
      <td>female</td>
      <td>28.0</td>
      <td>1</td>
      <td>2</td>
      <td>23.4500</td>
      <td>S</td>
      <td>B</td>
      <td>Miss</td>
      <td>3</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>889</th>
      <td>1</td>
      <td>1</td>
      <td>Behr, Mr. Karl Howell</td>
      <td>male</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>30.0000</td>
      <td>C</td>
      <td>C</td>
      <td>Mr</td>
      <td>0</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>890</th>
      <td>0</td>
      <td>3</td>
      <td>Dooley, Mr. Patrick</td>
      <td>male</td>
      <td>32.0</td>
      <td>0</td>
      <td>0</td>
      <td>7.7500</td>
      <td>Q</td>
      <td>B</td>
      <td>Mr</td>
      <td>0</td>
      <td>adults</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 13 columns</p>
</div>




```python
sns.countplot(df1["Age_category"]);
```

    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\_decorators.py:36: FutureWarning: Pass the following variable as a keyword arg: x. From version 0.12, the only valid positional argument will be `data`, and passing other arguments without an explicit keyword will result in an error or misinterpretation.
      warnings.warn(
    


    
![png](output_62_1.png)
    



```python
df1["Fare"].agg(["max","min","mean"])
```




    max     512.329200
    min       0.000000
    mean     32.204208
    Name: Fare, dtype: float64




```python
sns.distplot(df1["Fare"]);
```

    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\distributions.py:2619: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    


    
![png](output_64_1.png)
    


# Bivariate alalysis


```python
df1.groupby("Pclass")["Age"].mean()
```




    Pclass
    1    36.812130
    2    29.765380
    3    25.932627
    Name: Age, dtype: float64




```python
sns.barplot(x="Pclass",y="Age",data=df1);
```


    
![png](output_67_0.png)
    



```python
df1.groupby("Sex")["Age"].mean()
```




    Sex
    female    27.929936
    male      30.140676
    Name: Age, dtype: float64




```python
sns.barplot(x="Sex",y="Age",data=df1);
```


    
![png](output_69_0.png)
    



```python
df1.groupby("Survived")["Age"].mean()
```




    Survived
    0    30.028233
    1    28.291433
    Name: Age, dtype: float64




```python
sns.barplot(x="Survived",y="Age",data=df1);
```


    
![png](output_71_0.png)
    



```python
sns.barplot(x="Survived",y="Age",hue="Sex",data=df1);
```


    
![png](output_72_0.png)
    



```python
sns.boxplot(x="Sex",y="Age",hue="Survived",data=df1);
```


    
![png](output_73_0.png)
    



```python

age_su=df1[df1["Survived"]==1]["Age"]
age_nsu=df1[df1["Survived"]==0]["Age"]
sns.distplot(age_su,label="survived")
sns.distplot(age_nsu,label="not_survived")
plt.legend();



```

    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\distributions.py:2619: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    C:\ProgramData\Anaconda3\lib\site-packages\seaborn\distributions.py:2619: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    


    
![png](output_74_1.png)
    



```python
sns.scatterplot(x="Age",y="Fare",data=df1);
```


    
![png](output_75_0.png)
    


- find out the avg fare of each pclass of psnnger
- find out the avg fare spent by male and felame of each pclass
- of which group pupile died  most
- who died most (male or female)
- of which embaerkrd pssenf-ger died most
- find out the avg fare spent by survived aur not survived passenger
- how many male and female survived of each class
- how fare is related with family member
- 





```python
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
      <th>Embarked</th>
      <th>cabin_name</th>
      <th>salutation</th>
      <th>family_member</th>
      <th>Age_category</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>7.2500</td>
      <td>S</td>
      <td>B</td>
      <td>Mr</td>
      <td>1</td>
      <td>youth</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>71.2833</td>
      <td>C</td>
      <td>C</td>
      <td>Mrs</td>
      <td>1</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>7.9250</td>
      <td>S</td>
      <td>B</td>
      <td>Miss</td>
      <td>0</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>53.1000</td>
      <td>S</td>
      <td>C</td>
      <td>Mrs</td>
      <td>1</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>8.0500</td>
      <td>S</td>
      <td>B</td>
      <td>Mr</td>
      <td>0</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>886</th>
      <td>0</td>
      <td>2</td>
      <td>Montvila, Rev. Juozas</td>
      <td>male</td>
      <td>27.0</td>
      <td>0</td>
      <td>0</td>
      <td>13.0000</td>
      <td>S</td>
      <td>B</td>
      <td>Rev</td>
      <td>0</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>887</th>
      <td>1</td>
      <td>1</td>
      <td>Graham, Miss. Margaret Edith</td>
      <td>female</td>
      <td>19.0</td>
      <td>0</td>
      <td>0</td>
      <td>30.0000</td>
      <td>S</td>
      <td>B</td>
      <td>Miss</td>
      <td>0</td>
      <td>youth</td>
    </tr>
    <tr>
      <th>888</th>
      <td>0</td>
      <td>3</td>
      <td>Johnston, Miss. Catherine Helen "Carrie"</td>
      <td>female</td>
      <td>28.0</td>
      <td>1</td>
      <td>2</td>
      <td>23.4500</td>
      <td>S</td>
      <td>B</td>
      <td>Miss</td>
      <td>3</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>889</th>
      <td>1</td>
      <td>1</td>
      <td>Behr, Mr. Karl Howell</td>
      <td>male</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>30.0000</td>
      <td>C</td>
      <td>C</td>
      <td>Mr</td>
      <td>0</td>
      <td>adults</td>
    </tr>
    <tr>
      <th>890</th>
      <td>0</td>
      <td>3</td>
      <td>Dooley, Mr. Patrick</td>
      <td>male</td>
      <td>32.0</td>
      <td>0</td>
      <td>0</td>
      <td>7.7500</td>
      <td>Q</td>
      <td>B</td>
      <td>Mr</td>
      <td>0</td>
      <td>adults</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 13 columns</p>
</div>




```python
df1.groupby("Pclass")["Fare"].mean()
```




    Pclass
    1    84.154687
    2    20.662183
    3    13.675550
    Name: Fare, dtype: float64




```python
sns.scatterplot()
```




    <AxesSubplot:>




    
![png](output_79_1.png)
    



```python
sns.relplot(x="Pclass",y="Fare",data=df1);
```


    
![png](output_80_0.png)
    



```python
sns.barplot(x="Pclass",y="Fare",data=df1);
```


    
![png](output_81_0.png)
    



```python
df1.groupby("Sex")["Fare"].mean()
```




    Sex
    female    44.479818
    male      25.523893
    Name: Fare, dtype: float64




```python
sns.barplot(x="Sex",y="Fare",data=df1);
```


    
![png](output_83_0.png)
    



```python
df1.groupby("Survived")["Age_category"].max()
```




    Survived
    0    older
    1    older
    Name: Age_category, dtype: category
    Categories (4, object): ['children' < 'youth' < 'adults' < 'older']




```python


```


```python
sns.barplot(x="Age_category",y="Survived",data=df1);
```


    
![png](output_86_0.png)
    



```python
sns.countplot(x="Survived",hue="Age_category",data=df1);
```


    
![png](output_87_0.png)
    



```python
sns.countplot(x="Survived",hue="Sex",data=df1);
```


    
![png](output_88_0.png)
    



```python

sns.countplot(x="Survived",hue="Embarked",data=df1);
```


    
![png](output_89_0.png)
    



```python
df1.groupby("Survived")["Fare"].mean()
```




    Survived
    0    22.117887
    1    48.395408
    Name: Fare, dtype: float64




```python
df1.groupby("Survived")["Sex","Pclass"].value_counts()
```

    C:\Users\SHAASHANK JOSHI\AppData\Local\Temp\ipykernel_22416\1789625027.py:1: FutureWarning: Indexing with multiple keys (implicitly converted to a tuple of keys) will be deprecated, use a list instead.
      df1.groupby("Survived")["Sex","Pclass"].value_counts()
    




    Survived  Sex     Pclass
    0         male    3         300
                      2          91
                      1          77
              female  3          72
                      2           6
                      1           3
    1         female  1          91
                      3          72
                      2          70
              male    3          47
                      1          45
                      2          17
    dtype: int64




```python

```
